import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath = path === "/" || path.startsWith("/auth/") || path === "/games" || path.startsWith("/api/")

  // Check if user is logged in from the cookie
  const isLoggedIn = request.cookies.get("userLoggedIn")?.value === "true"

  // Redirect logic
  if (!isPublicPath && !isLoggedIn) {
    // Redirect to login page with the original URL as the redirect parameter
    return NextResponse.redirect(new URL(`/auth/login?redirect=${path}`, request.url))
  }

  // If user is logged in and trying to access login/register page, redirect to home
  if (isLoggedIn && (path === "/auth/login" || path === "/auth/register")) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  return NextResponse.next()
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ["/account/:path*", "/admin/:path*", "/auth/login", "/auth/register", "/games/:path*"],
}
