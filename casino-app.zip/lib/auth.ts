// Simple authentication utilities for demo purposes
// In a real app, you would use a proper authentication system

export type UserRole = "admin" | "owner" | "user"

export interface User {
  id: string
  username: string
  email: string
  role: UserRole
  balance: number
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null

  const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"
  if (!isLoggedIn) return null

  const role = (localStorage.getItem("userRole") as UserRole) || "user"
  const username = localStorage.getItem("userName") || "User"

  return {
    id: "user-1",
    username,
    email: `${username.toLowerCase()}@example.com`,
    role,
    balance: Number.parseInt(localStorage.getItem("userBalance") || "5000"),
  }
}

export function isAuthenticated(): boolean {
  if (typeof window === "undefined") return false
  return localStorage.getItem("userLoggedIn") === "true"
}

export function hasRole(role: UserRole): boolean {
  if (typeof window === "undefined") return false
  const userRole = localStorage.getItem("userRole")
  return isAuthenticated() && userRole === role
}

export function logout(): void {
  if (typeof window === "undefined") return
  localStorage.removeItem("userLoggedIn")
  localStorage.removeItem("userRole")
  localStorage.removeItem("userName")
}

export function logActivity(action: string, details: string): void {
  if (typeof window === "undefined") return

  const user = getCurrentUser()
  if (!user) return

  const logs = JSON.parse(localStorage.getItem("activityLogs") || "[]")
  logs.push({
    action,
    user: user.username,
    timestamp: new Date().toISOString(),
    details,
  })

  localStorage.setItem("activityLogs", JSON.stringify(logs))
}
