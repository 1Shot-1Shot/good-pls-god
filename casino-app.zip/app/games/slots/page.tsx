"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, CastleIcon as Casino, Coins, RotateCcw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { SlotReelAnimation } from "@/components/animations/slot-reel-animation"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

const SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "💎", "7️⃣", "🎰"]
const ROWS = 3
const COLS = 5

export default function SlotsPage() {
  const [reels, setReels] = useState<string[][]>(Array(COLS).fill(Array(ROWS).fill("❓")))
  const [spinning, setSpinning] = useState(false)
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [win, setWin] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when win is set
  useEffect(() => {
    if (win > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [win])

  const spin = () => {
    if (balance < bet) return

    setBalance((prev) => prev - bet)
    setWin(0)
    setSpinning(true)

    // Generate random symbols for each position
    const newReels: string[][] = []

    for (let col = 0; col < COLS; col++) {
      const column: string[] = []
      for (let row = 0; row < ROWS; row++) {
        column.push(SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
      }
      newReels.push(column)
    }

    // Animate the spin with staggered timing for each reel
    const spinDuration = 2000 // Total spin duration

    setTimeout(() => {
      setReels(newReels)
      setSpinning(false)

      // Check for wins (simplified)
      let winAmount = 0

      // Check middle row for matches
      const middleRow = newReels.map((col) => col[1])
      const uniqueSymbols = new Set(middleRow)

      if (uniqueSymbols.size === 1) {
        // All 5 symbols match
        const symbol = middleRow[0]
        const multiplier = SYMBOLS.indexOf(symbol) + 5
        winAmount = bet * multiplier
      } else if (uniqueSymbols.size === 2) {
        // Potential 3 or 4 of a kind
        for (const symbol of uniqueSymbols) {
          const count = middleRow.filter((s) => s === symbol).length
          if (count >= 3) {
            const multiplier = Math.max(1, count - 2) * (SYMBOLS.indexOf(symbol) + 1)
            winAmount = bet * multiplier
            break
          }
        }
      }

      if (winAmount > 0) {
        setWin(winAmount)
        setBalance((prev) => prev + winAmount)
      }
    }, spinDuration)
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <Casino className="h-5 w-5 text-red-500" />
            <span className="text-lg font-bold">Slots Bonanza</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-4 py-1">
              <Coins className="h-4 w-4 text-yellow-500" />
              <span className="font-medium">{balance.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="mb-8 w-full max-w-2xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          <div className="mb-6 grid grid-cols-5 gap-2">
            {reels.map((col, colIndex) => (
              <div key={colIndex} className="flex flex-col">
                {col.map((symbol, rowIndex) => (
                  <div
                    key={`${colIndex}-${rowIndex}`}
                    className={`flex h-20 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 text-4xl
                      ${rowIndex === 1 && "border-yellow-500 bg-zinc-700"}`}
                  >
                    <SlotReelAnimation
                      spinning={spinning}
                      symbol={symbol}
                      index={colIndex}
                      isMiddleRow={rowIndex === 1}
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>

          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-zinc-400">Bet Amount</p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                  disabled={spinning}
                >
                  -
                </Button>
                <ChipAnimation isWinning={win > 0} amount={win}>
                  <span className="w-16 text-center font-bold">{bet}</span>
                </ChipAnimation>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                  disabled={spinning}
                >
                  +
                </Button>
              </div>
            </div>

            {win > 0 && (
              <div className="rounded-lg bg-green-900/50 px-4 py-2 text-center">
                <p className="text-sm text-green-400">You Won!</p>
                <p className="text-xl font-bold text-green-300">{win.toLocaleString()}</p>
              </div>
            )}

            <Button
              size="lg"
              className="bg-red-600 hover:bg-red-700"
              onClick={spin}
              disabled={spinning || balance < bet}
            >
              {spinning ? <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> : <Casino className="mr-2 h-4 w-4" />}
              {spinning ? "Spinning..." : "Spin"}
            </Button>
          </div>

          <div className="rounded-lg bg-zinc-800 p-3 text-sm text-zinc-400">
            <p className="mb-1 font-medium text-zinc-300">Payouts:</p>
            <p>3 matching symbols: 1-3x your bet</p>
            <p>4 matching symbols: 2-4x your bet</p>
            <p>5 matching symbols: 5-10x your bet</p>
            <p>Higher value symbols pay more!</p>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={win > 0} amount={win} message="BIG WIN!" />}
    </div>
  )
}
