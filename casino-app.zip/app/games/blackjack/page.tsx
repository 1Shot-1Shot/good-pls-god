"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, CastleIcon as Casino, RotateCcw, Spade } from "lucide-react"

import { Button } from "@/components/ui/button"
import { UserBalance } from "@/components/user-balance"
import { CardAnimation } from "@/components/animations/card-animation"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

type CardSuit = "♠️" | "♥️" | "♦️" | "♣️"
type CardRank = "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K" | "A"

interface PlayingCard {
  suit: CardSuit
  rank: CardRank
  value: number
  hidden?: boolean
}

const SUITS: CardSuit[] = ["♠️", "♥️", "♦️", "♣️"]
const RANKS: CardRank[] = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
const VALUES: Record<CardRank, number[]> = {
  "2": [2],
  "3": [3],
  "4": [4],
  "5": [5],
  "6": [6],
  "7": [7],
  "8": [8],
  "9": [9],
  "10": [10],
  J: [10],
  Q: [10],
  K: [10],
  A: [1, 11], // Ace can be 1 or 11
}

export default function BlackjackPage() {
  const [deck, setDeck] = useState<PlayingCard[]>([])
  const [playerHand, setPlayerHand] = useState<PlayingCard[]>([])
  const [dealerHand, setDealerHand] = useState<PlayingCard[]>([])
  const [gameState, setGameState] = useState<"idle" | "dealing" | "player-turn" | "dealer-turn" | "result">("idle")
  const [result, setResult] = useState<"win" | "lose" | "push" | "blackjack" | null>(null)
  const [bet, setBet] = useState(100)
  const [balance, setBalance] = useState(5000)
  const [winAmount, setWinAmount] = useState(0)
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [isDealing, setIsDealing] = useState(false)
  const [isFlipping, setIsFlipping] = useState(false)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when result is set
  useEffect(() => {
    if ((result === "win" || result === "blackjack") && winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [result, winAmount])

  const initializeDeck = () => {
    const newDeck: PlayingCard[] = []
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        newDeck.push({ suit, rank, value: VALUES[rank][0] })
      }
    }

    // Shuffle
    for (let i = newDeck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]]
    }

    return newDeck
  }

  const dealCards = () => {
    if (balance < bet) {
      setMessage("Insufficient balance")
      return
    }

    setIsLoading(true)
    setMessage("")
    setResult(null)
    setWinAmount(0)
    setIsDealing(true)

    // Deduct bet from balance
    setBalance((prev) => prev - bet)

    const newDeck = initializeDeck()
    setDeck(newDeck)

    // Deal initial cards
    const pHand = [newDeck[0], newDeck[2]]
    const dHand = [{ ...newDeck[1], hidden: true }, newDeck[3]]

    setPlayerHand([])
    setDealerHand([])

    // Simulate dealing animation
    setTimeout(() => {
      setPlayerHand(pHand)
      setDealerHand(dHand)

      setTimeout(() => {
        setIsLoading(false)
        setIsDealing(false)
        setGameState("player-turn")

        // Check for blackjack
        const playerScore = calculateHandValue(pHand)
        if (playerScore === 21) {
          handleDealerTurn(pHand)
        }
      }, 1000)
    }, 500)
  }

  const calculateHandValue = (hand: PlayingCard[]) => {
    let value = 0
    let aces = 0

    // First pass: count non-aces and track aces
    for (const card of hand) {
      if (card.hidden) continue
      if (card.rank === "A") {
        aces++
      } else {
        value += card.value
      }
    }

    // Second pass: add aces with optimal values
    for (let i = 0; i < aces; i++) {
      if (value + 11 <= 21) {
        value += 11
      } else {
        value += 1
      }
    }

    return value
  }

  const hit = () => {
    if (gameState !== "player-turn") return

    const newCard = deck[playerHand.length + dealerHand.length]
    const newHand = [...playerHand, newCard]
    setPlayerHand(newHand)

    const newScore = calculateHandValue(newHand)
    if (newScore > 21) {
      // Bust
      setResult("lose")
      setMessage("Bust! You went over 21.")
      setGameState("result")
    } else if (newScore === 21) {
      // Auto-stand on 21
      stand()
    }
  }

  const stand = () => {
    if (gameState !== "player-turn") return
    handleDealerTurn(playerHand)
  }

  const handleDealerTurn = (finalPlayerHand: PlayingCard[]) => {
    setGameState("dealer-turn")
    setIsFlipping(true)

    // Reveal dealer's hidden card
    const revealedDealerHand = dealerHand.map((card) => ({ ...card, hidden: false }))
    setDealerHand(revealedDealerHand)

    setTimeout(() => {
      setIsFlipping(false)
      let currentDealerHand = [...revealedDealerHand]
      let dealerScore = calculateHandValue(currentDealerHand)
      const playerScore = calculateHandValue(finalPlayerHand)

      // Check for player blackjack
      const playerHasBlackjack = playerScore === 21 && finalPlayerHand.length === 2
      const dealerHasBlackjack = dealerScore === 21 && currentDealerHand.length === 2

      if (playerHasBlackjack) {
        if (dealerHasBlackjack) {
          // Both have blackjack - push
          setResult("push")
          setWinAmount(bet)
          setBalance((prev) => prev + bet)
          setMessage("Both have Blackjack! Push.")
        } else {
          // Player has blackjack, dealer doesn't
          const blackjackPayout = Math.floor(bet * 2.5)
          setResult("blackjack")
          setWinAmount(blackjackPayout)
          setBalance((prev) => prev + blackjackPayout)
          setMessage("Blackjack! You win 3:2.")
        }
        setGameState("result")
        return
      }

      // Dealer draws until 17 or higher
      const drawCard = () => {
        const nextCardIndex = playerHand.length + dealerHand.length + currentDealerHand.length - dealerHand.length
        const nextCard = deck[nextCardIndex]
        currentDealerHand = [...currentDealerHand, nextCard]
        dealerScore = calculateHandValue(currentDealerHand)
        setDealerHand(currentDealerHand)

        if (dealerScore < 17) {
          setTimeout(drawCard, 500)
        } else {
          determineWinner(playerScore, dealerScore)
        }
      }

      if (dealerScore < 17) {
        drawCard()
      } else {
        determineWinner(playerScore, dealerScore)
      }
    }, 1000)
  }

  const determineWinner = (playerScore: number, dealerScore: number) => {
    let newResult: "win" | "lose" | "push" | "blackjack" = "lose"
    let newWinAmount = 0
    let resultMessage = ""

    if (playerScore > 21) {
      newResult = "lose"
      resultMessage = "Bust! You went over 21."
    } else if (dealerScore > 21) {
      newResult = "win"
      newWinAmount = bet * 2
      resultMessage = "Dealer busts! You win."
    } else if (playerScore > dealerScore) {
      newResult = "win"
      newWinAmount = bet * 2
      resultMessage = "You win!"
    } else if (playerScore < dealerScore) {
      newResult = "lose"
      resultMessage = "Dealer wins."
    } else {
      newResult = "push"
      newWinAmount = bet
      resultMessage = "Push! It's a tie."
    }

    setResult(newResult)
    setWinAmount(newWinAmount)
    setMessage(resultMessage)

    if (newWinAmount > 0) {
      setBalance((prev) => prev + newWinAmount)
    }

    setGameState("result")
  }

  const doubleDown = () => {
    if (gameState !== "player-turn" || playerHand.length !== 2 || balance < bet) return

    // Double the bet
    setBalance((prev) => prev - bet)
    setBet((prev) => prev * 2)

    // Draw one card and stand
    const newCard = deck[playerHand.length + dealerHand.length]
    const newHand = [...playerHand, newCard]
    setPlayerHand(newHand)

    setTimeout(() => {
      const newScore = calculateHandValue(newHand)
      if (newScore > 21) {
        // Bust
        setResult("lose")
        setMessage("Bust! You went over 21.")
        setGameState("result")
      } else {
        handleDealerTurn(newHand)
      }
    }, 500)
  }

  const getCardColor = (suit: CardSuit) => {
    return suit === "♥️" || suit === "♦️" ? "text-red-500" : "text-white"
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <Spade className="h-5 w-5 text-red-500" />
            <span className="text-lg font-bold">Blackjack</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="mb-8 w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Dealer's hand */}
          <div className="mb-8">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-sm font-medium text-zinc-400">Dealer's Hand</h3>
              {gameState !== "idle" && (
                <span className="text-lg font-bold">
                  {gameState === "player-turn" && dealerHand.some((c) => c.hidden)
                    ? "?"
                    : calculateHandValue(dealerHand)}
                </span>
              )}
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {dealerHand.length > 0 ? (
                dealerHand.map((card, index) => (
                  <div
                    key={index}
                    className={`flex h-32 w-24 flex-col items-center justify-center rounded-lg border border-zinc-700 ${
                      card.hidden ? "bg-red-900" : "bg-zinc-800"
                    } ${!card.hidden ? getCardColor(card.suit) : ""}`}
                  >
                    <CardAnimation
                      index={index}
                      isDealing={isDealing}
                      isFlipping={isFlipping && card.hidden}
                      delay={0.5}
                    >
                      {card.hidden ? (
                        <Casino className="h-10 w-10 text-red-700" />
                      ) : (
                        <>
                          <div className="text-lg font-bold">{card.rank}</div>
                          <div className="text-3xl">{card.suit}</div>
                        </>
                      )}
                    </CardAnimation>
                  </div>
                ))
              ) : (
                <div className="flex h-32 w-24 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800">
                  <span className="text-2xl text-zinc-600">?</span>
                </div>
              )}
            </div>
          </div>

          {/* Game result */}
          {result && (
            <div className="mb-4 text-center">
              <div
                className={`inline-block rounded-lg px-4 py-2 font-bold ${
                  result === "win" || result === "blackjack"
                    ? "bg-green-900/50 text-green-300"
                    : result === "lose"
                      ? "bg-red-900/50 text-red-300"
                      : "bg-yellow-900/50 text-yellow-300"
                }`}
              >
                {message} {winAmount > 0 && `+${winAmount}`}
              </div>
            </div>
          )}

          {/* Player's hand */}
          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-sm font-medium text-zinc-400">Your Hand</h3>
              {gameState !== "idle" && <span className="text-lg font-bold">{calculateHandValue(playerHand)}</span>}
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {playerHand.length > 0 ? (
                playerHand.map((card, index) => (
                  <div
                    key={index}
                    className={`flex h-32 w-24 flex-col items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 ${getCardColor(
                      card.suit,
                    )}`}
                  >
                    <CardAnimation index={index} isDealing={isDealing}>
                      <div className="text-lg font-bold">{card.rank}</div>
                      <div className="text-3xl">{card.suit}</div>
                    </CardAnimation>
                  </div>
                ))
              ) : (
                <div className="flex h-32 w-24 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800">
                  <span className="text-2xl text-zinc-600">?</span>
                </div>
              )}
            </div>
          </div>

          {/* Game controls */}
          <div className="flex flex-col items-center gap-4">
            {gameState === "idle" || gameState === "result" ? (
              <div className="w-full space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <p className="text-sm">Bet Amount:</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={gameState === "player-turn" || gameState === "dealer-turn"}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={result === "win" || result === "blackjack"} amount={winAmount}>
                    <span className="w-16 text-center font-bold">{bet}</span>
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={gameState === "player-turn" || gameState === "dealer-turn"}
                  >
                    +
                  </Button>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={dealCards}
                  disabled={isLoading || balance < bet}
                >
                  {isLoading ? (
                    <>
                      <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> Dealing...
                    </>
                  ) : (
                    "Deal Cards"
                  )}
                </Button>
              </div>
            ) : gameState === "player-turn" ? (
              <div className="flex w-full flex-wrap gap-2">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={hit}
                  disabled={gameState !== "player-turn"}
                >
                  Hit
                </Button>
                <Button
                  className="flex-1 bg-red-600 hover:bg-red-700"
                  onClick={stand}
                  disabled={gameState !== "player-turn"}
                >
                  Stand
                </Button>
                <Button
                  className="flex-1 bg-yellow-600 hover:bg-yellow-700"
                  onClick={doubleDown}
                  disabled={gameState !== "player-turn" || playerHand.length !== 2 || balance < bet}
                >
                  Double Down
                </Button>
              </div>
            ) : gameState === "dealer-turn" ? (
              <div className="flex h-10 items-center gap-2 text-zinc-400">
                <RotateCcw className="h-4 w-4 animate-spin" />
                Dealer's turn...
              </div>
            ) : null}

            {message && gameState !== "result" && <p className="text-center text-sm text-zinc-400">{message}</p>}
          </div>
        </div>

        <div className="w-full max-w-3xl rounded-lg bg-zinc-900 p-4 text-sm text-zinc-400">
          <p className="mb-1 font-medium text-zinc-300">Blackjack Rules:</p>
          <p>• Beat the dealer by getting a hand value closer to 21 without going over</p>
          <p>• Face cards are worth 10, Aces are worth 1 or 11</p>
          <p>• Blackjack (Ace + 10-value card) pays 3:2</p>
          <p>• Dealer must hit until 17 or higher</p>
          <p>• Double Down: Double your bet and receive exactly one more card</p>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && (
        <WinAnimation
          isWinning={result === "win" || result === "blackjack"}
          amount={winAmount}
          message={result === "blackjack" ? "BLACKJACK!" : "YOU WIN!"}
        />
      )}
    </div>
  )
}
