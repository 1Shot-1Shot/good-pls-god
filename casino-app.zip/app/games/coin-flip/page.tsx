"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { UserBalance } from "@/components/user-balance"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

export default function CoinFlipPage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [isFlipping, setIsFlipping] = useState(false)
  const [result, setResult] = useState<"heads" | "tails" | null>(null)
  const [choice, setChoice] = useState<"heads" | "tails">("heads")
  const [winAmount, setWinAmount] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [flipHistory, setFlipHistory] = useState<Array<{ result: "heads" | "tails"; win: boolean }>>([])

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set
  useEffect(() => {
    if (winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount])

  const flipCoin = () => {
    if (balance < bet || isFlipping) return

    setBalance((prev) => prev - bet)
    setIsFlipping(true)
    setResult(null)
    setWinAmount(0)

    // Simulate coin flip animation
    setTimeout(() => {
      // 50/50 chance with a slight house edge
      const random = Math.random()
      const houseEdge = 0.02 // 2% house edge
      const adjustedRandom = random * (1 - houseEdge)
      const newResult = adjustedRandom < 0.5 ? "heads" : "tails"

      setResult(newResult)

      // Check if win
      const isWin = newResult === choice

      // Update history
      setFlipHistory((prev) => [{ result: newResult, win: isWin }, ...prev.slice(0, 9)])

      if (isWin) {
        const winnings = bet * 2 // 2x payout (minus house edge)
        setWinAmount(winnings)
        setBalance((prev) => prev + winnings)
      }

      setIsFlipping(false)
    }, 2000)
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🪙</span>
            <span className="text-lg font-bold">Coin Flip</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Coin Display */}
          <div className="mb-8 flex flex-col items-center">
            <div className="relative mb-4 h-40 w-40">
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                animate={
                  isFlipping
                    ? {
                        rotateY: [0, 1080],
                        scale: [1, 1.2, 1],
                      }
                    : {}
                }
                transition={{
                  duration: 2,
                  ease: "easeInOut",
                }}
              >
                <div
                  className={`h-32 w-32 rounded-full ${
                    result === "heads"
                      ? "bg-gradient-to-r from-yellow-400 to-yellow-600"
                      : result === "tails"
                        ? "bg-gradient-to-r from-gray-400 to-gray-600"
                        : "bg-gradient-to-r from-yellow-400 to-yellow-600"
                  } flex items-center justify-center border-4 border-yellow-700 shadow-lg`}
                >
                  {isFlipping ? (
                    <RotateCcw className="h-12 w-12 animate-spin text-yellow-800" />
                  ) : result ? (
                    <span className="text-4xl font-bold text-yellow-900">{result === "heads" ? "H" : "T"}</span>
                  ) : (
                    <span className="text-4xl font-bold text-yellow-900">?</span>
                  )}
                </div>
              </motion.div>
            </div>

            {result && (
              <div
                className={`mb-4 rounded-lg px-4 py-2 text-center ${
                  result === choice ? "bg-green-900/50 text-green-300" : "bg-red-900/50 text-red-300"
                }`}
              >
                {result === choice ? (
                  <p className="font-bold">
                    You won {winAmount}! ({result.toUpperCase()})
                  </p>
                ) : (
                  <p className="font-bold">You lost! ({result.toUpperCase()})</p>
                )}
              </div>
            )}
          </div>

          {/* Bet Controls */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Bet Amount</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={isFlipping}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                    <Input
                      type="number"
                      value={bet}
                      onChange={(e) => setBet(Number(e.target.value))}
                      className="border-zinc-700 bg-zinc-800 text-center"
                      disabled={isFlipping}
                    />
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={isFlipping}
                  >
                    +
                  </Button>
                </div>
                <div className="mt-2 flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.1))}
                    disabled={isFlipping}
                  >
                    10%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.25))}
                    disabled={isFlipping}
                  >
                    25%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.5))}
                    disabled={isFlipping}
                  >
                    50%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(balance)}
                    disabled={isFlipping}
                  >
                    Max
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Choose Side</label>
                <div className="flex gap-2">
                  <Button
                    className={`flex-1 ${
                      choice === "heads" ? "bg-yellow-600 hover:bg-yellow-700" : "bg-zinc-700 hover:bg-zinc-600"
                    }`}
                    onClick={() => setChoice("heads")}
                    disabled={isFlipping}
                  >
                    Heads
                  </Button>
                  <Button
                    className={`flex-1 ${
                      choice === "tails" ? "bg-gray-600 hover:bg-gray-700" : "bg-zinc-700 hover:bg-zinc-600"
                    }`}
                    onClick={() => setChoice("tails")}
                    disabled={isFlipping}
                  >
                    Tails
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-zinc-800 p-4">
                <div className="mb-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-zinc-400">Win Chance</p>
                    <p className="text-xl font-bold">49%</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Multiplier</p>
                    <p className="text-xl font-bold">2.00x</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Potential Win</p>
                    <p className="text-xl font-bold text-green-500">{(bet * 2).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Your Choice</p>
                    <p className="text-xl font-bold">{choice.charAt(0).toUpperCase() + choice.slice(1)}</p>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={flipCoin}
                  disabled={isFlipping || balance < bet}
                >
                  {isFlipping ? (
                    <>
                      <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> Flipping...
                    </>
                  ) : (
                    "Flip Coin"
                  )}
                </Button>
              </div>

              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-medium">Flip History</h3>
                <div className="flex flex-wrap gap-2">
                  {flipHistory.length > 0 ? (
                    flipHistory.map((flip, index) => (
                      <div
                        key={index}
                        className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold ${
                          flip.win ? "bg-green-600" : "bg-red-600"
                        }`}
                      >
                        {flip.result === "heads" ? "H" : "T"}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-zinc-400">No flips yet</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-lg bg-zinc-800 p-4 text-sm text-zinc-400">
            <p className="mb-1 font-medium text-zinc-300">How to Play:</p>
            <p>1. Set your bet amount</p>
            <p>2. Choose Heads or Tails</p>
            <p>3. Flip the coin and see if you win</p>
            <p>4. Win 2x your bet if you guess correctly</p>
            <p>5. House edge: 2%</p>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
