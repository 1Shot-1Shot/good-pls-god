"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, TrendingDown, TrendingUp } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { UserBalance } from "@/components/user-balance"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

export default function CrashPage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [multiplier, setMultiplier] = useState(1.0)
  const [isCrashed, setIsCrashed] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [hasCashedOut, setHasCashedOut] = useState(false)
  const [winAmount, setWinAmount] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [gameHistory, setGameHistory] = useState<number[]>([])
  const [autoCashout, setAutoCashout] = useState(2.0)
  const [isAutoEnabled, setIsAutoEnabled] = useState(false)

  const animationRef = useRef<number>(0)
  const lastUpdateRef = useRef<number>(0)
  const crashPointRef = useRef<number>(1.0)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }

    // Initialize game history with random values
    setGameHistory([1.24, 3.12, 1.87, 1.05, 4.56, 1.32, 2.45, 1.78, 1.15, 5.67])
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set
  useEffect(() => {
    if (winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount])

  // Clean up animation frame on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  // Handle auto cashout
  useEffect(() => {
    if (isPlaying && isAutoEnabled && multiplier >= autoCashout && !hasCashedOut) {
      handleCashout()
    }
  }, [multiplier, isPlaying, isAutoEnabled, autoCashout, hasCashedOut])

  const startGame = () => {
    if (balance < bet || isPlaying) return

    // Deduct bet from balance
    setBalance((prev) => prev - bet)

    // Reset game state
    setMultiplier(1.0)
    setIsCrashed(false)
    setIsPlaying(true)
    setHasCashedOut(false)
    setWinAmount(0)

    // Generate random crash point (between 1.0 and 10.0)
    // With house edge making lower values more common
    const random = Math.random()
    const houseEdge = 0.05 // 5% house edge
    const crashPoint = 1.0 + Math.pow(random, 0.9) * 9.0 * (1 - houseEdge)
    crashPointRef.current = crashPoint

    // Start animation
    lastUpdateRef.current = performance.now()
    animateMultiplier()
  }

  const animateMultiplier = () => {
    const now = performance.now()
    const deltaTime = now - lastUpdateRef.current
    lastUpdateRef.current = now

    // Increase multiplier exponentially
    // The formula creates an exponential curve that starts slow and accelerates
    const increment = (deltaTime / 1000) * Math.pow(multiplier, 1.1) * 0.5
    const newMultiplier = multiplier + increment

    // Check if crashed
    if (newMultiplier >= crashPointRef.current) {
      setMultiplier(Number.parseFloat(crashPointRef.current.toFixed(2)))
      setIsCrashed(true)
      setIsPlaying(false)

      // Add to history
      setGameHistory((prev) => [crashPointRef.current, ...prev.slice(0, 9)])

      return
    }

    setMultiplier(Number.parseFloat(newMultiplier.toFixed(2)))
    animationRef.current = requestAnimationFrame(animateMultiplier)
  }

  const handleCashout = () => {
    if (!isPlaying || hasCashedOut) return

    // Cancel animation
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }

    // Calculate winnings
    const winnings = Math.floor(bet * multiplier)
    setWinAmount(winnings)
    setBalance((prev) => prev + winnings)

    // Update state
    setHasCashedOut(true)
    setIsPlaying(false)
  }

  const getMultiplierColor = () => {
    if (isCrashed) return "text-red-500"
    if (multiplier >= 5) return "text-purple-500"
    if (multiplier >= 3) return "text-yellow-500"
    if (multiplier >= 2) return "text-green-500"
    return "text-white"
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">📉</span>
            <span className="text-lg font-bold">Crash</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Multiplier Display */}
          <div className="mb-8 flex flex-col items-center">
            <div className="mb-4 flex h-40 w-full items-center justify-center rounded-lg bg-zinc-800">
              {isCrashed ? (
                <div className="flex flex-col items-center">
                  <TrendingDown className="mb-2 h-12 w-12 text-red-500" />
                  <p className="text-6xl font-bold text-red-500">{multiplier.toFixed(2)}x</p>
                  <p className="mt-2 text-xl font-bold text-red-500">CRASHED!</p>
                </div>
              ) : isPlaying ? (
                <div className="flex flex-col items-center">
                  <TrendingUp className={`mb-2 h-12 w-12 ${getMultiplierColor()}`} />
                  <p className={`text-6xl font-bold ${getMultiplierColor()}`}>{multiplier.toFixed(2)}x</p>
                </div>
              ) : (
                <div className="flex flex-col items-center text-zinc-400">
                  <p className="text-2xl font-bold">Place your bet</p>
                  <p className="mt-2">The multiplier will grow until it crashes</p>
                </div>
              )}
            </div>

            {hasCashedOut && (
              <div className="mb-4 rounded-lg bg-green-900/50 px-4 py-2 text-center text-green-300">
                <p className="font-bold">
                  Cashed out at {multiplier.toFixed(2)}x! You won {winAmount}!
                </p>
              </div>
            )}
          </div>

          {/* Game History */}
          <div className="mb-6">
            <h3 className="mb-2 font-medium">Game History</h3>
            <div className="flex flex-wrap gap-2">
              {gameHistory.map((crash, index) => (
                <div
                  key={index}
                  className={`rounded-full px-3 py-1 text-xs font-bold ${
                    crash >= 5
                      ? "bg-purple-600"
                      : crash >= 3
                        ? "bg-yellow-600"
                        : crash >= 2
                          ? "bg-green-600"
                          : "bg-red-600"
                  }`}
                >
                  {crash.toFixed(2)}x
                </div>
              ))}
            </div>
          </div>

          {/* Bet Controls */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Bet Amount</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={isPlaying}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                    <Input
                      type="number"
                      value={bet}
                      onChange={(e) => setBet(Number(e.target.value))}
                      className="border-zinc-700 bg-zinc-800 text-center"
                      disabled={isPlaying}
                    />
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={isPlaying}
                  >
                    +
                  </Button>
                </div>
                <div className="mt-2 flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.1))}
                    disabled={isPlaying}
                  >
                    10%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.25))}
                    disabled={isPlaying}
                  >
                    25%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.5))}
                    disabled={isPlaying}
                  >
                    50%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(balance)}
                    disabled={isPlaying}
                  >
                    Max
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Auto Cashout</label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={autoCashout}
                    onChange={(e) => setAutoCashout(Number(e.target.value))}
                    className="border-zinc-700 bg-zinc-800 text-center"
                    disabled={isPlaying}
                    step="0.1"
                    min="1.1"
                  />
                  <Button
                    variant={isAutoEnabled ? "default" : "outline"}
                    className={isAutoEnabled ? "bg-green-600 hover:bg-green-700" : "border-zinc-700 bg-zinc-800"}
                    onClick={() => setIsAutoEnabled(!isAutoEnabled)}
                    disabled={isPlaying}
                  >
                    {isAutoEnabled ? "Enabled" : "Disabled"}
                  </Button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-zinc-800 p-4">
                <div className="mb-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-zinc-400">Current Bet</p>
                    <p className="text-xl font-bold">{bet}</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Potential Win</p>
                    <p className="text-xl font-bold text-green-500">
                      {isPlaying ? Math.floor(bet * multiplier) : bet * 2}
                    </p>
                  </div>
                </div>

                {isPlaying && !hasCashedOut ? (
                  <Button size="lg" className="w-full bg-green-600 hover:bg-green-700" onClick={handleCashout}>
                    Cash Out @ {multiplier.toFixed(2)}x
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    className="w-full bg-red-600 hover:bg-red-700"
                    onClick={startGame}
                    disabled={isPlaying || balance < bet}
                  >
                    {isPlaying ? (
                      <>
                        <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> Playing...
                      </>
                    ) : (
                      "Place Bet"
                    )}
                  </Button>
                )}
              </div>

              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-medium">How to Play</h3>
                <ul className="space-y-1 text-sm text-zinc-400">
                  <li>1. Place your bet</li>
                  <li>2. The multiplier starts at 1.00x and grows</li>
                  <li>3. Cash out before the game crashes</li>
                  <li>4. If you cash out, you win your bet × multiplier</li>
                  <li>5. If it crashes before you cash out, you lose your bet</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="CASHED OUT!" />}
    </div>
  )
}
