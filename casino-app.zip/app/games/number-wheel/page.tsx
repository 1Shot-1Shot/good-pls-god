"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { UserBalance } from "@/components/user-balance"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

// Define wheel segments
const WHEEL_SEGMENTS = [
  { value: 0, multiplier: 0, color: "#16a34a" }, // Green 0
  { value: 1, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 2, multiplier: 2, color: "#000000" }, // Black
  { value: 3, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 4, multiplier: 2, color: "#000000" }, // Black
  { value: 5, multiplier: 5, color: "#ef4444" }, // Red
  { value: 6, multiplier: 2, color: "#000000" }, // Black
  { value: 7, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 8, multiplier: 2, color: "#000000" }, // Black
  { value: 9, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 10, multiplier: 10, color: "#000000" }, // Black
  { value: 11, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 12, multiplier: 2, color: "#000000" }, // Black
  { value: 13, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 14, multiplier: 2, color: "#000000" }, // Black
  { value: 15, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 16, multiplier: 2, color: "#000000" }, // Black
  { value: 17, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 18, multiplier: 2, color: "#000000" }, // Black
  { value: 19, multiplier: 1.5, color: "#ef4444" }, // Red
  { value: 20, multiplier: 20, color: "#000000" }, // Black
]

export default function NumberWheelPage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [isSpinning, setIsSpinning] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [winAmount, setWinAmount] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [spinHistory, setSpinHistory] = useState<number[]>([])
  const [selectedSegments, setSelectedSegments] = useState<number[]>([])
  const [wheelRotation, setWheelRotation] = useState(0)

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const wheelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }

    // Draw the wheel
    drawWheel()
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set
  useEffect(() => {
    if (winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount])

  // Draw the wheel on canvas
  const drawWheel = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(centerX, centerY) - 10

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw segments
    const segmentAngle = (2 * Math.PI) / WHEEL_SEGMENTS.length

    WHEEL_SEGMENTS.forEach((segment, index) => {
      const startAngle = index * segmentAngle
      const endAngle = (index + 1) * segmentAngle

      // Draw segment
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.closePath()

      // Fill segment
      ctx.fillStyle = segment.color
      ctx.fill()

      // Draw segment text
      ctx.save()
      ctx.translate(centerX, centerY)
      ctx.rotate(startAngle + segmentAngle / 2)
      ctx.textAlign = "right"
      ctx.fillStyle = segment.color === "#000000" ? "#ffffff" : "#ffffff"
      ctx.font = "bold 16px Arial"
      ctx.fillText(`${segment.value}`, radius - 20, 5)
      ctx.fillText(`${segment.multiplier}x`, radius - 20, 25)
      ctx.restore()
    })

    // Draw center circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, 20, 0, 2 * Math.PI)
    ctx.fillStyle = "#374151"
    ctx.fill()

    // Draw pointer
    ctx.beginPath()
    ctx.moveTo(centerX, centerY - radius - 10)
    ctx.lineTo(centerX - 10, centerY - radius + 10)
    ctx.lineTo(centerX + 10, centerY - radius + 10)
    ctx.closePath()
    ctx.fillStyle = "#ef4444"
    ctx.fill()
  }

  const toggleSegmentSelection = (value: number) => {
    if (isSpinning) return

    if (selectedSegments.includes(value)) {
      setSelectedSegments(selectedSegments.filter((v) => v !== value))
    } else {
      setSelectedSegments([...selectedSegments, value])
    }
  }

  const spinWheel = () => {
    if (balance < bet || isSpinning || selectedSegments.length === 0) return

    // Deduct bet from balance
    setBalance((prev) => prev - bet * selectedSegments.length)

    setIsSpinning(true)
    setResult(null)
    setWinAmount(0)

    // Generate random result
    // Apply house edge by slightly reducing the chance of winning
    const houseEdge = 0.05 // 5% house edge
    const random = Math.random()

    let resultIndex: number

    if (random < houseEdge) {
      // Force a loss by selecting a non-selected segment
      const nonSelectedIndices = WHEEL_SEGMENTS.map((segment, index) => index).filter(
        (index) => !selectedSegments.includes(WHEEL_SEGMENTS[index].value),
      )

      resultIndex = nonSelectedIndices[Math.floor(Math.random() * nonSelectedIndices.length)]
    } else {
      // Normal random selection
      resultIndex = Math.floor(Math.random() * WHEEL_SEGMENTS.length)
    }

    const resultValue = WHEEL_SEGMENTS[resultIndex].value

    // Calculate rotation to land on the result
    // The wheel rotates clockwise, so we need to calculate the opposite position
    const segmentAngle = 360 / WHEEL_SEGMENTS.length
    const destinationAngle = 360 - resultIndex * segmentAngle + 360 * 5 // Spin 5 full rotations plus the destination

    // Animate wheel
    setWheelRotation(destinationAngle)

    // Set result after animation
    setTimeout(() => {
      setResult(resultValue)
      setSpinHistory([resultValue, ...spinHistory.slice(0, 9)])

      // Check if win
      if (selectedSegments.includes(resultValue)) {
        const segment = WHEEL_SEGMENTS.find((s) => s.value === resultValue)
        if (segment) {
          const winnings = Math.floor(bet * segment.multiplier)
          setWinAmount(winnings)
          setBalance((prev) => prev + winnings)
        }
      }

      setIsSpinning(false)
    }, 5000) // Match animation duration
  }

  const getSegmentColor = (value: number) => {
    const segment = WHEEL_SEGMENTS.find((s) => s.value === value)
    return segment ? segment.color : "#000000"
  }

  const getMultiplier = (value: number) => {
    const segment = WHEEL_SEGMENTS.find((s) => s.value === value)
    return segment ? segment.multiplier : 0
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🔢</span>
            <span className="text-lg font-bold">Number Wheel</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Wheel Display */}
          <div className="mb-8 flex flex-col items-center">
            <div className="relative mb-4 h-64 w-64">
              <motion.div
                ref={wheelRef}
                className="absolute inset-0"
                animate={{ rotate: wheelRotation }}
                transition={{
                  duration: 5,
                  ease: "easeOut",
                }}
              >
                <canvas ref={canvasRef} width={300} height={300} className="h-full w-full" />
              </motion.div>
            </div>

            {result !== null && (
              <div
                className={`mb-4 rounded-lg px-4 py-2 text-center ${
                  selectedSegments.includes(result) ? "bg-green-900/50 text-green-300" : "bg-red-900/50 text-red-300"
                }`}
              >
                {selectedSegments.includes(result) ? (
                  <p className="font-bold">
                    You won {winAmount}! (Landed on {result})
                  </p>
                ) : (
                  <p className="font-bold">You lost! (Landed on {result})</p>
                )}
              </div>
            )}
          </div>

          {/* Bet Controls */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Bet Amount (per number)</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={isSpinning}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                    <Input
                      type="number"
                      value={bet}
                      onChange={(e) => setBet(Number(e.target.value))}
                      className="border-zinc-700 bg-zinc-800 text-center"
                      disabled={isSpinning}
                    />
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={isSpinning}
                  >
                    +
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Select Numbers</label>
                <div className="grid grid-cols-7 gap-2">
                  {WHEEL_SEGMENTS.map((segment) => (
                    <button
                      key={segment.value}
                      className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold ${
                        selectedSegments.includes(segment.value)
                          ? "ring-2 ring-yellow-500 ring-offset-2 ring-offset-zinc-900"
                          : ""
                      }`}
                      style={{ backgroundColor: segment.color }}
                      onClick={() => toggleSegmentSelection(segment.value)}
                      disabled={isSpinning}
                    >
                      {segment.value}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-zinc-800 p-4">
                <div className="mb-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-zinc-400">Selected Numbers</p>
                    <p className="text-xl font-bold">{selectedSegments.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Total Bet</p>
                    <p className="text-xl font-bold">{bet * selectedSegments.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Potential Win (max)</p>
                    <p className="text-xl font-bold text-green-500">
                      {selectedSegments.length > 0
                        ? Math.max(...selectedSegments.map((v) => Math.floor(bet * getMultiplier(v))))
                        : 0}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Last Result</p>
                    <p className="text-xl font-bold">{result !== null ? result : "-"}</p>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={spinWheel}
                  disabled={isSpinning || balance < bet * selectedSegments.length || selectedSegments.length === 0}
                >
                  {isSpinning ? (
                    <>
                      <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> Spinning...
                    </>
                  ) : (
                    "Spin Wheel"
                  )}
                </Button>
              </div>

              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-medium">Spin History</h3>
                <div className="flex flex-wrap gap-2">
                  {spinHistory.length > 0 ? (
                    spinHistory.map((value, index) => (
                      <div
                        key={index}
                        className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold"
                        style={{ backgroundColor: getSegmentColor(value) }}
                      >
                        {value}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-zinc-400">No spins yet</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 rounded-lg bg-zinc-800 p-4 text-sm text-zinc-400">
            <p className="mb-1 font-medium text-zinc-300">How to Play:</p>
            <p>1. Select one or more numbers on the wheel</p>
            <p>2. Set your bet amount (per number)</p>
            <p>3. Spin the wheel and see where it lands</p>
            <p>4. Win according to the multiplier of the landed number</p>
            <p>5. Special multipliers: 0 (0x), 5 (5x), 10 (10x), 20 (20x)</p>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
