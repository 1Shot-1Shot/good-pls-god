"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { UserBalance } from "@/components/user-balance"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

interface Tile {
  revealed: boolean
  isMine: boolean
}

export default function MinesPage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [mineCount, setMineCount] = useState(5)
  const [tiles, setTiles] = useState<Tile[]>(Array(25).fill({ revealed: false, isMine: false }))
  const [isPlaying, setIsPlaying] = useState(false)
  const [isGameOver, setIsGameOver] = useState(false)
  const [winAmount, setWinAmount] = useState(0)
  const [currentMultiplier, setCurrentMultiplier] = useState(1.0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [revealedCount, setRevealedCount] = useState(0)
  const [nextMultiplier, setNextMultiplier] = useState(1.0)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set and game is cashed out
  useEffect(() => {
    if (winAmount > 0 && !isPlaying && !isGameOver) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount, isPlaying, isGameOver])

  // Calculate next multiplier based on revealed tiles and mine count
  useEffect(() => {
    if (isPlaying) {
      // Calculate the probability of hitting a safe tile
      const remainingTiles = 25 - revealedCount
      const remainingMines = mineCount
      const safeProb = (remainingTiles - remainingMines) / remainingTiles

      // Calculate the fair multiplier (1/probability)
      // Apply a house edge of 3%
      const houseEdge = 0.03
      const fairMultiplier = 1 / safeProb
      const nextMult = fairMultiplier * (1 - houseEdge)

      setNextMultiplier(Number.parseFloat(nextMult.toFixed(2)))
    }
  }, [isPlaying, revealedCount, mineCount])

  const startGame = () => {
    if (balance < bet || isPlaying) return

    // Deduct bet from balance
    setBalance((prev) => prev - bet)

    // Reset game state
    setIsPlaying(true)
    setIsGameOver(false)
    setWinAmount(0)
    setRevealedCount(0)
    setCurrentMultiplier(1.0)

    // Generate mine positions
    const minePositions = new Set<number>()
    while (minePositions.size < mineCount) {
      const position = Math.floor(Math.random() * 25)
      minePositions.add(position)
    }

    // Create tiles
    const newTiles = Array(25)
      .fill(null)
      .map((_, index) => ({
        revealed: false,
        isMine: minePositions.has(index),
      }))

    setTiles(newTiles)
  }

  const revealTile = (index: number) => {
    if (!isPlaying || tiles[index].revealed) return

    const newTiles = [...tiles]
    newTiles[index].revealed = true

    if (newTiles[index].isMine) {
      // Hit a mine - game over
      setIsGameOver(true)
      setIsPlaying(false)

      // Reveal all mines
      newTiles.forEach((tile, i) => {
        if (tile.isMine) {
          newTiles[i].revealed = true
        }
      })
    } else {
      // Safe tile - update multiplier
      setRevealedCount((prev) => prev + 1)
      setCurrentMultiplier(nextMultiplier)
    }

    setTiles(newTiles)
  }

  const cashout = () => {
    if (!isPlaying || isGameOver) return

    // Calculate winnings
    const winnings = Math.floor(bet * currentMultiplier)
    setWinAmount(winnings)
    setBalance((prev) => prev + winnings)

    // End game
    setIsPlaying(false)

    // Reveal all mines
    const newTiles = [...tiles]
    newTiles.forEach((tile, i) => {
      if (tile.isMine) {
        newTiles[i].revealed = true
      }
    })

    setTiles(newTiles)
  }

  const getTileContent = (tile: Tile) => {
    if (!tile.revealed) {
      return "?"
    }

    if (tile.isMine) {
      return "💣"
    }

    return "💎"
  }

  const getTileClass = (tile: Tile) => {
    if (!tile.revealed) {
      return "bg-zinc-800 hover:bg-zinc-700"
    }

    if (tile.isMine) {
      return "bg-red-600"
    }

    return "bg-green-600"
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">💣</span>
            <span className="text-lg font-bold">Mines</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Game Board */}
          <div className="mb-6">
            <div className="grid grid-cols-5 gap-2">
              {tiles.map((tile, index) => (
                <button
                  key={index}
                  className={`flex h-14 w-full items-center justify-center rounded-lg border border-zinc-700 text-xl font-bold ${getTileClass(tile)}`}
                  onClick={() => revealTile(index)}
                  disabled={!isPlaying || tile.revealed}
                >
                  {getTileContent(tile)}
                </button>
              ))}
            </div>
          </div>

          {/* Game Status */}
          <div className="mb-6 flex items-center justify-between rounded-lg border border-zinc-800 bg-zinc-800 p-4">
            <div>
              <p className="text-sm text-zinc-400">Current Multiplier</p>
              <p className="text-2xl font-bold text-green-500">{currentMultiplier.toFixed(2)}x</p>
            </div>
            <div>
              <p className="text-sm text-zinc-400">Next Tile</p>
              <p className="text-2xl font-bold text-yellow-500">{nextMultiplier.toFixed(2)}x</p>
            </div>
            <div>
              <p className="text-sm text-zinc-400">Mines</p>
              <p className="text-2xl font-bold text-red-500">{mineCount}</p>
            </div>
            <div>
              <p className="text-sm text-zinc-400">Revealed</p>
              <p className="text-2xl font-bold">
                {revealedCount}/{25 - mineCount}
              </p>
            </div>
          </div>

          {/* Game Controls */}
          <div className="grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Bet Amount</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={isPlaying}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                    <Input
                      type="number"
                      value={bet}
                      onChange={(e) => setBet(Number(e.target.value))}
                      className="border-zinc-700 bg-zinc-800 text-center"
                      disabled={isPlaying}
                    />
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={isPlaying}
                  >
                    +
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Number of Mines: {mineCount}</label>
                <Slider
                  value={[mineCount]}
                  min={1}
                  max={24}
                  step={1}
                  onValueChange={(value) => setMineCount(value[0])}
                  disabled={isPlaying}
                  className="py-4"
                />
                <div className="mt-2 flex justify-between text-xs text-zinc-400">
                  <span>1 (Easy)</span>
                  <span>12</span>
                  <span>24 (Hard)</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-zinc-800 p-4">
                {isGameOver ? (
                  <div className="mb-4 rounded-lg bg-red-900/50 p-3 text-center text-red-300">
                    <p className="text-lg font-bold">BOOM! You hit a mine!</p>
                  </div>
                ) : winAmount > 0 ? (
                  <div className="mb-4 rounded-lg bg-green-900/50 p-3 text-center text-green-300">
                    <p className="text-lg font-bold">You won {winAmount}!</p>
                  </div>
                ) : null}

                {isPlaying ? (
                  <Button size="lg" className="w-full bg-green-600 hover:bg-green-700" onClick={cashout}>
                    Cash Out ({Math.floor(bet * currentMultiplier)})
                  </Button>
                ) : (
                  <Button
                    size="lg"
                    className="w-full bg-red-600 hover:bg-red-700"
                    onClick={startGame}
                    disabled={isPlaying || balance < bet}
                  >
                    {isGameOver ? "Play Again" : "Start Game"}
                  </Button>
                )}
              </div>

              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-medium">How to Play</h3>
                <ul className="space-y-1 text-sm text-zinc-400">
                  <li>1. Set your bet and number of mines</li>
                  <li>2. Click on tiles to reveal them</li>
                  <li>3. Avoid mines and find gems</li>
                  <li>4. Cash out anytime to secure your winnings</li>
                  <li>5. The fewer mines, the lower the potential payout</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
