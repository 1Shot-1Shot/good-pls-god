"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Coins, Dice5, RotateCcw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { RouletteWheelAnimation } from "@/components/animations/roulette-wheel-animation"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

type BetType = "red" | "black" | "green" | "1-18" | "19-36" | "even" | "odd" | number

interface Bet {
  type: BetType
  amount: number
}

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]

export default function RoulettePage() {
  const [balance, setBalance] = useState(5000)
  const [currentBet, setCurrentBet] = useState<number>(10)
  const [bets, setBets] = useState<Bet[]>([])
  const [spinning, setSpinning] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [lastResults, setLastResults] = useState<number[]>([])
  const [winAmount, setWinAmount] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [chipAnimations, setChipAnimations] = useState<{ [key: string]: boolean }>({})

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set
  useEffect(() => {
    if (winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount])

  const placeBet = (type: BetType) => {
    if (spinning) return
    if (balance < currentBet) return

    setBalance((prev) => prev - currentBet)

    // Animate the chip
    const betKey = typeof type === "number" ? `num-${type}` : type
    setChipAnimations((prev) => ({ ...prev, [betKey]: true }))

    setTimeout(() => {
      setChipAnimations((prev) => ({ ...prev, [betKey]: false }))
    }, 500)

    // Check if bet on same type already exists
    const existingBetIndex = bets.findIndex((bet) => bet.type === type)

    if (existingBetIndex >= 0) {
      const updatedBets = [...bets]
      updatedBets[existingBetIndex].amount += currentBet
      setBets(updatedBets)
    } else {
      setBets([...bets, { type, amount: currentBet }])
    }
  }

  const spin = () => {
    if (bets.length === 0 || spinning) return

    setSpinning(true)
    setWinAmount(0)

    setTimeout(() => {
      const newResult = Math.floor(Math.random() * 37) // 0-36
      setResult(newResult)
      setLastResults((prev) => [newResult, ...prev].slice(0, 10))

      // Calculate winnings after spin animation completes
      setTimeout(() => {
        calculateWinnings(newResult)
      }, 500)
    }, 3000) // Match the wheel animation duration
  }

  const calculateWinnings = (newResult: number) => {
    // Calculate winnings
    let totalWin = 0

    bets.forEach((bet) => {
      let win = 0

      if (typeof bet.type === "number" && bet.type === newResult) {
        // Straight up bet pays 35:1
        win = bet.amount * 36
      } else if (bet.type === "red" && RED_NUMBERS.includes(newResult)) {
        // Red pays 1:1
        win = bet.amount * 2
      } else if (bet.type === "black" && !RED_NUMBERS.includes(newResult) && newResult !== 0) {
        // Black pays 1:1
        win = bet.amount * 2
      } else if (bet.type === "green" && newResult === 0) {
        // Green (0) pays 35:1
        win = bet.amount * 36
      } else if (bet.type === "1-18" && newResult >= 1 && newResult <= 18) {
        // 1-18 pays 1:1
        win = bet.amount * 2
      } else if (bet.type === "19-36" && newResult >= 19 && newResult <= 36) {
        // 19-36 pays 1:1
        win = bet.amount * 2
      } else if (bet.type === "even" && newResult !== 0 && newResult % 2 === 0) {
        // Even pays 1:1
        win = bet.amount * 2
      } else if (bet.type === "odd" && newResult % 2 === 1) {
        // Odd pays 1:1
        win = bet.amount * 2
      }

      totalWin += win
    })

    if (totalWin > 0) {
      setWinAmount(totalWin)
      setBalance((prev) => prev + totalWin)
    }

    setSpinning(false)
    setBets([])
  }

  const getNumberColor = (num: number) => {
    if (num === 0) return "bg-green-600"
    return RED_NUMBERS.includes(num) ? "bg-red-600" : "bg-zinc-900"
  }

  const handleSpinComplete = () => {
    // This function is called when the wheel animation completes
    // We already handle this with setTimeout in the spin function
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <Dice5 className="h-5 w-5 text-red-500" />
            <span className="text-lg font-bold">Roulette Royale</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-4 py-1">
              <Coins className="h-4 w-4 text-yellow-500" />
              <span className="font-medium">{balance.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center p-4">
        <div className="mb-6 w-full max-w-4xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Wheel result display */}
          <div className="mb-6 flex flex-col items-center">
            <div className="mb-4 flex items-center gap-2">
              {lastResults.map((num, i) => (
                <div
                  key={i}
                  className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ${getNumberColor(num)}`}
                >
                  {num}
                </div>
              ))}
            </div>

            <div className="relative mb-4 flex h-32 w-32 items-center justify-center">
              <RouletteWheelAnimation spinning={spinning} result={result} onSpinComplete={handleSpinComplete} />
            </div>

            {winAmount > 0 && (
              <div className="mb-4 rounded-lg bg-green-900/50 px-4 py-2 text-center">
                <p className="text-sm text-green-400">You Won!</p>
                <p className="text-xl font-bold text-green-300">{winAmount.toLocaleString()}</p>
              </div>
            )}

            <div className="mb-4 flex items-center gap-2">
              <p className="text-sm">Bet Amount:</p>
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setCurrentBet((prev) => Math.max(10, prev - 10))}
                disabled={spinning}
              >
                -
              </Button>
              <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                <span className="w-16 text-center font-bold">{currentBet}</span>
              </ChipAnimation>
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setCurrentBet((prev) => Math.min(1000, prev + 10))}
                disabled={spinning}
              >
                +
              </Button>
            </div>

            <div className="mb-4 flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                className={`border-red-600 bg-red-600 hover:bg-red-700 ${chipAnimations["red"] ? "animate-bounce" : ""}`}
                onClick={() => placeBet("red")}
                disabled={spinning || balance < currentBet}
              >
                Red
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`border-zinc-800 bg-zinc-900 hover:bg-zinc-800 ${chipAnimations["black"] ? "animate-bounce" : ""}`}
                onClick={() => placeBet("black")}
                disabled={spinning || balance < currentBet}
              >
                Black
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={`border-green-600 bg-green-600 hover:bg-green-700 ${chipAnimations["green"] ? "animate-bounce" : ""}`}
                onClick={() => placeBet("green")}
                disabled={spinning || balance < currentBet}
              >
                Green (0)
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={chipAnimations["1-18"] ? "animate-bounce" : ""}
                onClick={() => placeBet("1-18")}
                disabled={spinning || balance < currentBet}
              >
                1-18
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={chipAnimations["19-36"] ? "animate-bounce" : ""}
                onClick={() => placeBet("19-36")}
                disabled={spinning || balance < currentBet}
              >
                19-36
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={chipAnimations["even"] ? "animate-bounce" : ""}
                onClick={() => placeBet("even")}
                disabled={spinning || balance < currentBet}
              >
                Even
              </Button>
              <Button
                variant="outline"
                size="sm"
                className={chipAnimations["odd"] ? "animate-bounce" : ""}
                onClick={() => placeBet("odd")}
                disabled={spinning || balance < currentBet}
              >
                Odd
              </Button>
            </div>

            <Button
              size="lg"
              className="bg-yellow-600 hover:bg-yellow-700"
              onClick={spin}
              disabled={spinning || bets.length === 0}
            >
              {spinning ? <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> : <Dice5 className="mr-2 h-4 w-4" />}
              {spinning ? "Spinning..." : "Spin"}
            </Button>
          </div>

          {/* Number grid */}
          <div className="grid grid-cols-12 gap-2 sm:grid-cols-12">
            <div
              className={`flex h-10 cursor-pointer items-center justify-center rounded bg-green-600 font-bold ${chipAnimations["num-0"] ? "animate-bounce" : ""}`}
              onClick={() => placeBet(0)}
            >
              0
            </div>
            {Array.from({ length: 36 }).map((_, i) => {
              const num = i + 1
              return (
                <div
                  key={num}
                  className={`flex h-10 cursor-pointer items-center justify-center rounded font-bold ${
                    RED_NUMBERS.includes(num) ? "bg-red-600" : "bg-zinc-900"
                  } ${chipAnimations[`num-${num}`] ? "animate-bounce" : ""}`}
                  onClick={() => placeBet(num)}
                >
                  {num}
                </div>
              )
            })}
          </div>
        </div>

        {/* Current bets */}
        {bets.length > 0 && (
          <div className="w-full max-w-4xl rounded-xl border border-zinc-800 bg-zinc-900 p-4">
            <h3 className="mb-2 font-bold">Current Bets:</h3>
            <div className="flex flex-wrap gap-2">
              {bets.map((bet, i) => (
                <div key={i} className="rounded-full bg-zinc-800 px-3 py-1 text-sm">
                  {typeof bet.type === "number" ? `Number ${bet.type}` : bet.type}: {bet.amount}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
