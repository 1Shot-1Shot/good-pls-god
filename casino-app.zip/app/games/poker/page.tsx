"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, Coins, PinIcon as PokerChip, RotateCcw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { CardAnimation } from "@/components/animations/card-animation"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

type CardSuit = "♠️" | "♥️" | "♦️" | "♣️"
type CardRank = "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K" | "A"

interface PlayingCard {
  suit: CardSuit
  rank: CardRank
  value: number
}

const SUITS: CardSuit[] = ["♠️", "♥️", "♦️", "♣️"]
const RANKS: CardRank[] = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
const VALUES: Record<CardRank, number> = {
  "2": 2,
  "3": 3,
  "4": 4,
  "5": 5,
  "6": 6,
  "7": 7,
  "8": 8,
  "9": 9,
  "10": 10,
  J: 11,
  Q: 12,
  K: 13,
  A: 14,
}

export default function PokerPage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [deck, setDeck] = useState<PlayingCard[]>([])
  const [playerHand, setPlayerHand] = useState<PlayingCard[]>([])
  const [dealerHand, setDealerHand] = useState<PlayingCard[]>([])
  const [gameState, setGameState] = useState<"idle" | "dealing" | "player-turn" | "dealer-turn" | "result">("idle")
  const [result, setResult] = useState<"win" | "lose" | "tie" | null>(null)
  const [winAmount, setWinAmount] = useState(0)
  const [selectedCards, setSelectedCards] = useState<boolean[]>([false, false, false, false, false])
  const [isDealing, setIsDealing] = useState(false)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [isReplacing, setIsReplacing] = useState(false)

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when result is set
  useEffect(() => {
    if (result === "win" && winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [result, winAmount])

  // Initialize or shuffle deck
  const initializeDeck = () => {
    const newDeck: PlayingCard[] = []
    for (const suit of SUITS) {
      for (const rank of RANKS) {
        newDeck.push({ suit, rank, value: VALUES[rank] })
      }
    }

    // Shuffle
    for (let i = newDeck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]]
    }

    return newDeck
  }

  const dealCards = () => {
    if (balance < bet) return

    setBalance((prev) => prev - bet)
    setResult(null)
    setWinAmount(0)
    setSelectedCards([false, false, false, false, false])
    setIsDealing(true)

    const newDeck = initializeDeck()
    setDeck(newDeck)

    setGameState("dealing")

    // Clear hands first for animation
    setPlayerHand([])
    setDealerHand([])

    // Deal 5 cards to player and dealer with animation delay
    setTimeout(() => {
      const newPlayerHand = newDeck.slice(0, 5)
      const newDealerHand = newDeck.slice(5, 10)

      setPlayerHand(newPlayerHand)
      setDealerHand(newDealerHand)

      setTimeout(() => {
        setIsDealing(false)
        setGameState("player-turn")
      }, 1000)
    }, 500)
  }

  const toggleCardSelection = (index: number) => {
    if (gameState !== "player-turn") return

    const newSelectedCards = [...selectedCards]
    newSelectedCards[index] = !newSelectedCards[index]
    setSelectedCards(newSelectedCards)
  }

  const drawNewCards = () => {
    if (gameState !== "player-turn") return

    setIsReplacing(true)
    const newHand = [...playerHand]
    let currentDeckIndex = 10 // Start after the initial 10 cards dealt

    selectedCards.forEach((selected, index) => {
      if (selected) {
        newHand[index] = deck[currentDeckIndex]
        currentDeckIndex++
      }
    })

    setPlayerHand(newHand)
    setSelectedCards([false, false, false, false, false])

    setTimeout(() => {
      setIsReplacing(false)
      setGameState("dealer-turn")

      // Simple dealer AI - replace cards with values less than 10
      setTimeout(() => {
        const newDealerHand = [...dealerHand]

        dealerHand.forEach((card, index) => {
          if (card.value < 10) {
            newDealerHand[index] = deck[currentDeckIndex]
            currentDeckIndex++
          }
        })

        setDealerHand(newDealerHand)

        setTimeout(() => {
          determineWinner(newHand, newDealerHand)
        }, 1000)
      }, 1000)
    }, 500)
  }

  const determineWinner = (playerCards: PlayingCard[], dealerCards: PlayingCard[]) => {
    // Very simplified poker hand evaluation - just highest card for demo
    // In a real game, you'd check for pairs, straights, flushes, etc.

    const playerHighCard = Math.max(...playerCards.map((card) => card.value))
    const dealerHighCard = Math.max(...dealerCards.map((card) => card.value))

    let newResult: "win" | "lose" | "tie"
    let newWinAmount = 0

    if (playerHighCard > dealerHighCard) {
      newResult = "win"
      newWinAmount = bet * 2
      setBalance((prev) => prev + newWinAmount)
    } else if (playerHighCard < dealerHighCard) {
      newResult = "lose"
    } else {
      newResult = "tie"
      newWinAmount = bet
      setBalance((prev) => prev + newWinAmount)
    }

    setResult(newResult)
    setWinAmount(newWinAmount)
    setGameState("result")
  }

  const getCardColor = (suit: CardSuit) => {
    return suit === "♥️" || suit === "♦️" ? "text-red-500" : "text-white"
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <PokerChip className="h-5 w-5 text-red-500" />
            <span className="text-lg font-bold">Five Card Draw</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-4 py-1">
              <Coins className="h-4 w-4 text-yellow-500" />
              <span className="font-medium">{balance.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="mb-6 w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Dealer's hand */}
          <div className="mb-8">
            <h3 className="mb-2 text-center text-sm font-medium text-zinc-400">Dealer's Hand</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {dealerHand.length > 0
                ? dealerHand.map((card, index) => (
                    <div
                      key={index}
                      className={`flex h-32 w-24 flex-col items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800 ${getCardColor(
                        card.suit,
                      )}`}
                    >
                      <CardAnimation index={index} isDealing={isDealing} delay={0.5}>
                        <div className="text-lg font-bold">{card.rank}</div>
                        <div className="text-3xl">{card.suit}</div>
                      </CardAnimation>
                    </div>
                  ))
                : Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className="flex h-32 w-24 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800"
                    >
                      <span className="text-2xl text-zinc-600">?</span>
                    </div>
                  ))}
            </div>
          </div>

          {/* Game result */}
          {result && (
            <div className="mb-4 text-center">
              <div
                className={`inline-block rounded-lg px-4 py-2 font-bold ${
                  result === "win"
                    ? "bg-green-900/50 text-green-300"
                    : result === "lose"
                      ? "bg-red-900/50 text-red-300"
                      : "bg-yellow-900/50 text-yellow-300"
                }`}
              >
                {result === "win" ? `You Win! +${winAmount}` : result === "lose" ? "You Lose" : `Tie! +${winAmount}`}
              </div>
            </div>
          )}

          {/* Player's hand */}
          <div className="mb-6">
            <h3 className="mb-2 text-center text-sm font-medium text-zinc-400">Your Hand</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {playerHand.length > 0
                ? playerHand.map((card, index) => (
                    <div
                      key={index}
                      className={`flex h-32 w-24 cursor-pointer flex-col items-center justify-center rounded-lg border ${
                        selectedCards[index] ? "border-yellow-500 bg-zinc-700" : "border-zinc-700 bg-zinc-800"
                      } ${getCardColor(card.suit)}`}
                      onClick={() => toggleCardSelection(index)}
                    >
                      <CardAnimation
                        index={index}
                        isDealing={isDealing}
                        isFlipping={isReplacing && selectedCards[index]}
                      >
                        <div className="text-lg font-bold">{card.rank}</div>
                        <div className="text-3xl">{card.suit}</div>
                      </CardAnimation>
                    </div>
                  ))
                : Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className="flex h-32 w-24 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-800"
                    >
                      <span className="text-2xl text-zinc-600">?</span>
                    </div>
                  ))}
            </div>
          </div>

          {/* Game controls */}
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2">
              <p className="text-sm">Bet Amount:</p>
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                disabled={gameState !== "idle" && gameState !== "result"}
              >
                -
              </Button>
              <ChipAnimation isWinning={result === "win"} amount={winAmount}>
                <span className="w-16 text-center font-bold">{bet}</span>
              </ChipAnimation>
              <Button
                variant="outline"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                disabled={gameState !== "idle" && gameState !== "result"}
              >
                +
              </Button>
            </div>

            {(gameState === "idle" || gameState === "result") && (
              <Button size="lg" className="bg-red-600 hover:bg-red-700" onClick={dealCards} disabled={balance < bet}>
                <PokerChip className="mr-2 h-4 w-4" />
                Deal Cards
              </Button>
            )}

            {gameState === "player-turn" && (
              <div className="flex gap-2">
                <Button size="lg" className="bg-yellow-600 hover:bg-yellow-700" onClick={drawNewCards}>
                  {selectedCards.some((s) => s) ? "Draw New Cards" : "Keep All Cards"}
                </Button>
              </div>
            )}

            {gameState === "dealing" || gameState === "dealer-turn" ? (
              <div className="flex h-10 items-center gap-2 text-zinc-400">
                <RotateCcw className="h-4 w-4 animate-spin" />
                {gameState === "dealing" ? "Dealing cards..." : "Dealer's turn..."}
              </div>
            ) : null}
          </div>
        </div>

        <div className="w-full max-w-3xl rounded-lg bg-zinc-900 p-4 text-sm text-zinc-400">
          <p className="mb-1 font-medium text-zinc-300">How to Play:</p>
          <p>1. Set your bet amount and click "Deal Cards"</p>
          <p>2. Select the cards you want to replace (if any)</p>
          <p>3. Click "Draw New Cards" to replace selected cards</p>
          <p>4. The dealer will then replace their cards</p>
          <p>5. Highest hand wins! (This demo just compares highest card value)</p>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={result === "win"} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
