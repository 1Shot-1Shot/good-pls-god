"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { UserBalance } from "@/components/user-balance"
import { ChipAnimation } from "@/components/animations/chip-animation"
import { WinAnimation } from "@/components/animations/win-animation"

export default function DicePage() {
  const [balance, setBalance] = useState(5000)
  const [bet, setBet] = useState(100)
  const [targetNumber, setTargetNumber] = useState(50)
  const [betType, setBetType] = useState<"over" | "under">("over")
  const [rolling, setRolling] = useState(false)
  const [result, setResult] = useState<number | null>(null)
  const [winAmount, setWinAmount] = useState(0)
  const [showWinAnimation, setShowWinAnimation] = useState(false)
  const [rollHistory, setRollHistory] = useState<Array<{ roll: number; win: boolean }>>([])

  // Calculate win multiplier based on probability
  const getMultiplier = () => {
    const probability = betType === "over" ? (100 - targetNumber) / 100 : targetNumber / 100
    // Add house edge of 2%
    return probability > 0 ? (0.98 / probability).toFixed(2) : "0.00"
  }

  // Calculate win chance
  const getWinChance = () => {
    return betType === "over" ? 100 - targetNumber : targetNumber
  }

  useEffect(() => {
    // Load balance from localStorage
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    }
  }, [])

  // Save balance to localStorage when it changes
  useEffect(() => {
    localStorage.setItem("userBalance", balance.toString())
  }, [balance])

  // Show win animation when winAmount is set
  useEffect(() => {
    if (winAmount > 0) {
      setShowWinAnimation(true)
      const timer = setTimeout(() => {
        setShowWinAnimation(false)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [winAmount])

  const rollDice = () => {
    if (balance < bet || rolling) return

    setBalance((prev) => prev - bet)
    setRolling(true)
    setResult(null)
    setWinAmount(0)

    // Simulate dice roll animation
    setTimeout(() => {
      // Generate random number between 1 and 100
      const roll = Math.floor(Math.random() * 100) + 1
      setResult(roll)

      // Check if win
      const isWin = (betType === "over" && roll > targetNumber) || (betType === "under" && roll < targetNumber)

      // Update history
      setRollHistory((prev) => [{ roll, win: isWin }, ...prev.slice(0, 9)])

      if (isWin) {
        const multiplier = Number.parseFloat(getMultiplier())
        const winnings = Math.floor(bet * multiplier)
        setWinAmount(winnings)
        setBalance((prev) => prev + winnings)
      }

      setRolling(false)
    }, 1500)
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎲</span>
            <span className="text-lg font-bold">Dice Roll</span>
          </div>
          <div className="ml-auto flex items-center gap-4">
            <UserBalance />
          </div>
        </div>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-3xl rounded-xl border border-zinc-800 bg-zinc-900 p-6">
          {/* Result Display */}
          <div className="mb-8 flex flex-col items-center">
            <div className="mb-4 flex h-32 w-32 items-center justify-center rounded-full border-4 border-red-500 bg-zinc-800 text-5xl font-bold">
              {rolling ? <RotateCcw className="h-12 w-12 animate-spin text-red-500" /> : result !== null ? result : "?"}
            </div>

            {result !== null && (
              <div
                className={`mb-4 rounded-lg px-4 py-2 text-center ${
                  winAmount > 0 ? "bg-green-900/50 text-green-300" : "bg-red-900/50 text-red-300"
                }`}
              >
                {winAmount > 0 ? (
                  <p className="font-bold">
                    You won {winAmount}! ({result} is {betType} {targetNumber})
                  </p>
                ) : (
                  <p className="font-bold">
                    You lost! ({result} is {betType === "over" ? "not over" : "not under"} {targetNumber})
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Bet Controls */}
          <div className="mb-6 grid gap-6 md:grid-cols-2">
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Bet Amount</label>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.max(10, prev - 10))}
                    disabled={rolling}
                  >
                    -
                  </Button>
                  <ChipAnimation isWinning={winAmount > 0} amount={winAmount}>
                    <Input
                      type="number"
                      value={bet}
                      onChange={(e) => setBet(Number(e.target.value))}
                      className="border-zinc-700 bg-zinc-800 text-center"
                      disabled={rolling}
                    />
                  </ChipAnimation>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => setBet((prev) => Math.min(1000, prev + 10))}
                    disabled={rolling}
                  >
                    +
                  </Button>
                </div>
                <div className="mt-2 flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.1))}
                    disabled={rolling}
                  >
                    10%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.25))}
                    disabled={rolling}
                  >
                    25%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(Math.floor(balance * 0.5))}
                    disabled={rolling}
                  >
                    50%
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 bg-zinc-800"
                    onClick={() => setBet(balance)}
                    disabled={rolling}
                  >
                    Max
                  </Button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Target Number: {targetNumber}</label>
                <Slider
                  value={[targetNumber]}
                  min={1}
                  max={99}
                  step={1}
                  onValueChange={(value) => setTargetNumber(value[0])}
                  disabled={rolling}
                  className="py-4"
                />
                <div className="mt-2 flex justify-between text-xs text-zinc-400">
                  <span>1</span>
                  <span>50</span>
                  <span>99</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  className={`flex-1 ${
                    betType === "under" ? "bg-red-600 hover:bg-red-700" : "bg-zinc-700 hover:bg-zinc-600"
                  }`}
                  onClick={() => setBetType("under")}
                  disabled={rolling}
                >
                  Roll Under
                </Button>
                <Button
                  className={`flex-1 ${
                    betType === "over" ? "bg-green-600 hover:bg-green-700" : "bg-zinc-700 hover:bg-zinc-600"
                  }`}
                  onClick={() => setBetType("over")}
                  disabled={rolling}
                >
                  Roll Over
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <div className="rounded-lg border border-zinc-800 p-4">
                <div className="mb-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-zinc-400">Win Chance</p>
                    <p className="text-xl font-bold">{getWinChance()}%</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Multiplier</p>
                    <p className="text-xl font-bold">{getMultiplier()}x</p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Potential Win</p>
                    <p className="text-xl font-bold text-green-500">
                      {(bet * Number.parseFloat(getMultiplier())).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-zinc-400">Roll Target</p>
                    <p className="text-xl font-bold">{betType === "over" ? `>${targetNumber}` : `<${targetNumber}`}</p>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={rollDice}
                  disabled={rolling || balance < bet}
                >
                  {rolling ? (
                    <>
                      <RotateCcw className="mr-2 h-4 w-4 animate-spin" /> Rolling...
                    </>
                  ) : (
                    "Roll Dice"
                  )}
                </Button>
              </div>

              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-medium">Roll History</h3>
                <div className="flex flex-wrap gap-2">
                  {rollHistory.length > 0 ? (
                    rollHistory.map((roll, index) => (
                      <div
                        key={index}
                        className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold ${
                          roll.win ? "bg-green-600" : "bg-red-600"
                        }`}
                      >
                        {roll.roll}
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-zinc-400">No rolls yet</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-zinc-800 p-4 text-sm text-zinc-400">
            <p className="mb-1 font-medium text-zinc-300">How to Play:</p>
            <p>1. Set your bet amount</p>
            <p>2. Choose a target number (1-99)</p>
            <p>3. Select to roll over or under the target</p>
            <p>4. The lower your chances of winning, the higher your potential payout</p>
            <p>5. House edge: 2%</p>
          </div>
        </div>
      </main>

      {/* Win animation overlay */}
      {showWinAnimation && <WinAnimation isWinning={winAmount > 0} amount={winAmount} message="YOU WIN!" />}
    </div>
  )
}
