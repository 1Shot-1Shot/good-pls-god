import { GamesList } from "@/components/games-list"

export default function GamesListPage() {
  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Casino Games</h1>
        <GamesList />
      </div>
    </div>
  )
}
