"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, Eye, EyeOff } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Demo login logic - in a real app, this would be an API call
      if (email === "admin@example.com" && password === "password") {
        localStorage.setItem("userRole", "admin")
        localStorage.setItem("userLoggedIn", "true")
        localStorage.setItem("userName", "CasinoAdmin")
        router.push("/admin")
      } else if (email === "owner@example.com" && password === "password") {
        localStorage.setItem("userRole", "owner")
        localStorage.setItem("userLoggedIn", "true")
        localStorage.setItem("userName", "LuckyOwner")
        router.push("/")
      } else if (email && password.length >= 6) {
        localStorage.setItem("userRole", "user")
        localStorage.setItem("userLoggedIn", "true")
        localStorage.setItem("userName", email.split("@")[0])
        router.push("/")
      } else {
        setError("Invalid email or password")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="w-full max-w-md rounded-xl border border-zinc-800 bg-zinc-900 p-8">
          <div className="mb-6 flex flex-col items-center">
            <Casino className="mb-2 h-12 w-12 text-red-500" />
            <h1 className="text-2xl font-bold">Login to LuckyStrike Casino</h1>
            <p className="text-sm text-zinc-400">Enter your credentials to access your account</p>
          </div>

          {error && <div className="mb-4 rounded-lg bg-red-900/30 p-3 text-center text-sm text-red-300">{error}</div>}

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-zinc-700 bg-zinc-800 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="border-zinc-700 bg-zinc-800 pr-10 text-white"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                />
                <Label htmlFor="remember" className="text-sm">
                  Remember me
                </Label>
              </div>
              <Link href="/auth/forgot-password" className="text-sm text-red-400 hover:text-red-300">
                Forgot password?
              </Link>
            </div>

            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={isLoading}>
              {isLoading ? "Logging in..." : "Login"}
            </Button>

            <div className="text-center text-sm">
              <span className="text-zinc-400">Don't have an account?</span>{" "}
              <Link href="/auth/register" className="text-red-400 hover:text-red-300">
                Register
              </Link>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-zinc-700"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-zinc-900 px-2 text-zinc-400">Demo Accounts</span>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2 text-xs">
              <div className="rounded-lg border border-zinc-700 p-2">
                <p>
                  <strong>Admin:</strong> admin@example.com / password
                </p>
              </div>
              <div className="rounded-lg border border-zinc-700 p-2">
                <p>
                  <strong>Owner:</strong> owner@example.com / password
                </p>
              </div>
              <div className="rounded-lg border border-zinc-700 p-2">
                <p>
                  <strong>User:</strong> any email / password (min 6 chars)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
