"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, Eye, EyeOff } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [agreeTerms, setAgreeTerms] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Validate form
      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        setIsLoading(false)
        return
      }

      if (formData.password.length < 6) {
        setError("Password must be at least 6 characters")
        setIsLoading(false)
        return
      }

      if (!agreeTerms) {
        setError("You must agree to the terms and conditions")
        setIsLoading(false)
        return
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Demo registration logic - in a real app, this would be an API call
      localStorage.setItem("userRole", "user")
      localStorage.setItem("userLoggedIn", "true")
      localStorage.setItem("userName", formData.username || formData.email.split("@")[0])

      // Log the registration
      const logs = JSON.parse(localStorage.getItem("activityLogs") || "[]")
      logs.push({
        action: "User Registration",
        user: formData.username || formData.email.split("@")[0],
        timestamp: new Date().toISOString(),
        details: `New user registered with email ${formData.email}`,
      })
      localStorage.setItem("activityLogs", JSON.stringify(logs))

      router.push("/")
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <div className="flex flex-1 items-center justify-center p-4">
        <div className="w-full max-w-md rounded-xl border border-zinc-800 bg-zinc-900 p-8">
          <div className="mb-6 flex flex-col items-center">
            <Casino className="mb-2 h-12 w-12 text-red-500" />
            <h1 className="text-2xl font-bold">Create an Account</h1>
            <p className="text-sm text-zinc-400">Join LuckyStrike Casino and start playing</p>
          </div>

          {error && <div className="mb-4 rounded-lg bg-red-900/30 p-3 text-center text-sm text-red-300">{error}</div>}

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                name="username"
                placeholder="YourUsername"
                value={formData.username}
                onChange={handleChange}
                required
                className="border-zinc-700 bg-zinc-800 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="your.email@example.com"
                value={formData.email}
                onChange={handleChange}
                required
                className="border-zinc-700 bg-zinc-800 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  className="border-zinc-700 bg-zinc-800 pr-10 text-white"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <Input
                id="confirmPassword"
                name="confirmPassword"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                className="border-zinc-700 bg-zinc-800 text-white"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="terms"
                checked={agreeTerms}
                onCheckedChange={(checked) => setAgreeTerms(checked as boolean)}
                required
              />
              <Label htmlFor="terms" className="text-sm">
                I agree to the{" "}
                <Link href="/about/terms" className="text-red-400 hover:text-red-300">
                  Terms and Conditions
                </Link>{" "}
                and{" "}
                <Link href="/about/privacy" className="text-red-400 hover:text-red-300">
                  Privacy Policy
                </Link>
              </Label>
            </div>

            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={isLoading}>
              {isLoading ? "Creating Account..." : "Register"}
            </Button>

            <div className="text-center text-sm">
              <span className="text-zinc-400">Already have an account?</span>{" "}
              <Link href="/auth/login" className="text-red-400 hover:text-red-300">
                Login
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
