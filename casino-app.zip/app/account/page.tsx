"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { BarChart3, CastleIcon as Casino, ChevronRight, CreditCard, Gift, History, User } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { AccountLayout } from "@/components/account/account-layout"
import { getCurrentUser } from "@/lib/auth"

export default function AccountPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [recentTransactions, setRecentTransactions] = useState<any[]>([])
  const [recentGames, setRecentGames] = useState<any[]>([])

  useEffect(() => {
    const currentUser = getCurrentUser()

    if (!currentUser) {
      router.push("/auth/login?redirect=/account")
      return
    }

    setUser(currentUser)

    // Load transactions from localStorage
    const storedTransactions = localStorage.getItem(`transactions_${currentUser.id}`)
    if (storedTransactions) {
      const transactions = JSON.parse(storedTransactions)
      setRecentTransactions(transactions.slice(0, 5))
    }

    // Mock recent games data
    setRecentGames([
      { game: "Blackjack", date: "2025-05-18T14:30:00Z", result: "win", amount: 250 },
      { game: "Slots Bonanza", date: "2025-05-18T12:15:00Z", result: "loss", amount: -100 },
      { game: "Roulette Royale", date: "2025-05-17T20:45:00Z", result: "win", amount: 180 },
      { game: "Poker", date: "2025-05-17T18:20:00Z", result: "loss", amount: -50 },
    ])

    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  return (
    <AccountLayout>
      <div className="p-6">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Account Overview</h1>
          <div className="flex gap-2">
            <Link href="/account/settings">
              <Button variant="outline" className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700">
                Account Settings
              </Button>
            </Link>
            <Link href="/games">
              <Button className="bg-red-600 hover:bg-red-700">Play Now</Button>
            </Link>
          </div>
        </div>

        <div className="mb-6 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Current Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <CreditCard className="mr-2 h-4 w-4 text-green-400" />
                <span className="text-2xl font-bold">${user.balance.toLocaleString()}</span>
              </div>
              <Link href="/account/payment" className="mt-2 flex items-center text-xs text-zinc-400 hover:text-white">
                Deposit funds <ChevronRight className="ml-1 h-3 w-3" />
              </Link>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Account Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Badge variant="success">Active</Badge>
                <Badge variant={user.role === "vip" ? "yellow" : "outline"}>{user.role.toUpperCase()}</Badge>
              </div>
              <p className="mt-2 text-xs text-zinc-400">Member since {new Date().toLocaleDateString()}</p>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Available Bonuses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Gift className="mr-2 h-4 w-4 text-purple-400" />
                <span className="text-2xl font-bold">2</span>
              </div>
              <Link
                href="/account/promo-code"
                className="mt-2 flex items-center text-xs text-zinc-400 hover:text-white"
              >
                Redeem promo code <ChevronRight className="ml-1 h-3 w-3" />
              </Link>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Loyalty Points</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BarChart3 className="mr-2 h-4 w-4 text-yellow-400" />
                <span className="text-2xl font-bold">750</span>
              </div>
              <div className="mt-2 flex items-center text-xs text-zinc-400">
                <div className="h-1.5 w-full rounded-full bg-zinc-700">
                  <div className="h-1.5 rounded-full bg-yellow-500" style={{ width: "75%" }}></div>
                </div>
                <span className="ml-2 whitespace-nowrap">750/1000</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Your recent financial activity</CardDescription>
              </div>
              <Link href="/account/transactions">
                <Button variant="outline" size="sm" className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700">
                  View All
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {recentTransactions.length > 0 ? (
                <div className="space-y-4">
                  {recentTransactions.map((transaction, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between rounded-lg border border-zinc-800 p-3"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`rounded-full p-2 ${
                            transaction.type === "deposit" || transaction.type === "bonus"
                              ? "bg-green-900/30"
                              : transaction.type === "withdrawal"
                                ? "bg-red-900/30"
                                : "bg-blue-900/30"
                          }`}
                        >
                          <CreditCard
                            className={`h-4 w-4 ${
                              transaction.type === "deposit" || transaction.type === "bonus"
                                ? "text-green-400"
                                : transaction.type === "withdrawal"
                                  ? "text-red-400"
                                  : "text-blue-400"
                            }`}
                          />
                        </div>
                        <div>
                          <p className="font-medium">
                            {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1).replace("-", " ")}
                          </p>
                          <p className="text-xs text-zinc-400">{new Date(transaction.timestamp).toLocaleString()}</p>
                        </div>
                      </div>
                      <p className={`font-medium ${transaction.amount >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {transaction.amount >= 0 ? "+" : ""}
                        {transaction.amount}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-zinc-800 p-6 text-center">
                  <History className="mx-auto mb-2 h-8 w-8 text-zinc-500" />
                  <p className="text-zinc-400">No recent transactions</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Games</CardTitle>
                <CardDescription>Your recent gaming activity</CardDescription>
              </div>
              <Link href="/games">
                <Button variant="outline" size="sm" className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700">
                  Play Games
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentGames.map((game, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg border border-zinc-800 p-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`rounded-full p-2 ${game.result === "win" ? "bg-green-900/30" : "bg-red-900/30"}`}
                      >
                        <Casino className={`h-4 w-4 ${game.result === "win" ? "text-green-400" : "text-red-400"}`} />
                      </div>
                      <div>
                        <p className="font-medium">{game.game}</p>
                        <p className="text-xs text-zinc-400">{new Date(game.date).toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={game.result === "win" ? "success" : "destructive"}>
                        {game.result.toUpperCase()}
                      </Badge>
                      <p className={`mt-1 text-sm ${game.amount >= 0 ? "text-green-400" : "text-red-400"}`}>
                        {game.amount >= 0 ? "+" : ""}
                        {game.amount}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 border-zinc-800 bg-zinc-900">
          <CardHeader>
            <CardTitle>Account Badges</CardTitle>
            <CardDescription>Special tags and achievements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {user.tags && user.tags.length > 0 ? (
                user.tags.map((tag: string, index: number) => (
                  <Badge key={index} variant="outline" className="px-3 py-1.5">
                    {tag}
                  </Badge>
                ))
              ) : (
                <div className="rounded-lg border border-zinc-800 p-6 text-center w-full">
                  <User className="mx-auto mb-2 h-8 w-8 text-zinc-500" />
                  <p className="text-zinc-400">No badges yet</p>
                  <p className="mt-1 text-xs text-zinc-500">Play games and redeem promo codes to earn badges</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AccountLayout>
  )
}
