"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, Gift, Send } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AccountLayout } from "@/components/account/account-layout"
import { getCurrentUser, logActivity } from "@/lib/auth"

interface PromoCode {
  id: string
  code: string
  type: "money" | "tag" | "both"
  amount?: number
  tag?: string
  usageLimit: number
  usageCount: number
  expiryDate: string
  isActive: boolean
  createdBy: string
  createdAt: string
}

interface RedeemedCode {
  code: string
  redeemedAt: string
  reward: string
}

export default function PromoCodePage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const [promoCode, setPromoCode] = useState("")
  const [redeemedCodes, setRedeemedCodes] = useState<RedeemedCode[]>([])
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    const currentUser = getCurrentUser()

    if (!currentUser) {
      router.push("/auth/login?redirect=/account/promo-code")
      return
    }

    setUser(currentUser)

    // Load redeemed codes from localStorage
    const storedCodes = localStorage.getItem(`redeemedCodes_${currentUser.id}`)
    if (storedCodes) {
      setRedeemedCodes(JSON.parse(storedCodes))
    }

    setIsLoading(false)
  }, [router])

  const handleRedeemCode = async () => {
    if (!promoCode.trim() || !user) return

    setIsSubmitting(true)
    setMessage(null)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Check if code has already been redeemed by this user
    if (redeemedCodes.some((code) => code.code.toLowerCase() === promoCode.trim().toLowerCase())) {
      setMessage({ type: "error", text: "You have already redeemed this code" })
      setIsSubmitting(false)
      return
    }

    // Get all promo codes from localStorage
    const storedCodes = localStorage.getItem("promoCodes")
    let promoCodes: PromoCode[] = []

    if (storedCodes) {
      promoCodes = JSON.parse(storedCodes)
    }

    // Find the promo code
    const foundCode = promoCodes.find(
      (code) => code.code.toLowerCase() === promoCode.trim().toLowerCase() && code.isActive,
    )

    if (!foundCode) {
      setMessage({ type: "error", text: "Invalid or expired promo code" })
      setIsSubmitting(false)
      return
    }

    // Check if code has reached usage limit
    if (foundCode.usageCount >= foundCode.usageLimit) {
      setMessage({ type: "error", text: "This code has reached its usage limit" })
      setIsSubmitting(false)
      return
    }

    // Check if code has expired
    if (new Date(foundCode.expiryDate) < new Date()) {
      setMessage({ type: "error", text: "This code has expired" })
      setIsSubmitting(false)
      return
    }

    // Apply the promo code rewards
    let rewardDescription = ""

    // Handle money reward
    if (foundCode.type === "money" || foundCode.type === "both") {
      const amount = foundCode.amount || 0

      // Update user balance
      const updatedBalance = user.balance + amount

      // Update user in localStorage
      const storedUsers = localStorage.getItem("casinoUsers")
      if (storedUsers) {
        const users = JSON.parse(storedUsers)
        const updatedUsers = users.map((u: any) => {
          if (u.id === user.id) {
            return { ...u, balance: updatedBalance }
          }
          return u
        })

        localStorage.setItem("casinoUsers", JSON.stringify(updatedUsers))
      }

      // Update user in state
      setUser({ ...user, balance: updatedBalance })

      // Update balance in localStorage
      localStorage.setItem("userBalance", updatedBalance.toString())

      // Add transaction record
      const newTransaction = {
        id: `t${Date.now()}`,
        type: "bonus",
        amount: amount,
        timestamp: new Date().toISOString(),
        details: `Promo code ${foundCode.code} redemption`,
      }

      const storedTransactions = localStorage.getItem(`transactions_${user.id}`)
      let transactions = []

      if (storedTransactions) {
        transactions = JSON.parse(storedTransactions)
      }

      localStorage.setItem(`transactions_${user.id}`, JSON.stringify([newTransaction, ...transactions]))

      rewardDescription += `$${amount} bonus`
    }

    // Handle tag reward
    if (foundCode.type === "tag" || foundCode.type === "both") {
      const tag = foundCode.tag || ""

      // Update user tags
      const storedUsers = localStorage.getItem("casinoUsers")
      if (storedUsers) {
        const users = JSON.parse(storedUsers)
        const updatedUsers = users.map((u: any) => {
          if (u.id === user.id) {
            const tags = u.tags || []
            if (!tags.includes(tag)) {
              return { ...u, tags: [...tags, tag] }
            }
          }
          return u
        })

        localStorage.setItem("casinoUsers", JSON.stringify(updatedUsers))
      }

      if (rewardDescription) {
        rewardDescription += ` and "${tag}" tag`
      } else {
        rewardDescription += `"${tag}" tag`
      }
    }

    // Update promo code usage count
    const updatedPromoCodes = promoCodes.map((code) => {
      if (code.id === foundCode.id) {
        return { ...code, usageCount: code.usageCount + 1 }
      }
      return code
    })

    localStorage.setItem("promoCodes", JSON.stringify(updatedPromoCodes))

    // Add to redeemed codes
    const newRedeemedCode: RedeemedCode = {
      code: foundCode.code,
      redeemedAt: new Date().toISOString(),
      reward: rewardDescription,
    }

    const updatedRedeemedCodes = [newRedeemedCode, ...redeemedCodes]
    setRedeemedCodes(updatedRedeemedCodes)
    localStorage.setItem(`redeemedCodes_${user.id}`, JSON.stringify(updatedRedeemedCodes))

    // Log activity
    logActivity("Promo Code Redeemed", `Redeemed promo code ${foundCode.code} for ${rewardDescription}`)

    // Show success message
    setMessage({ type: "success", text: `Successfully redeemed code for ${rewardDescription}!` })
    setPromoCode("")
    setIsSubmitting(false)
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  return (
    <AccountLayout>
      <div className="p-6">
        <h1 className="mb-6 text-2xl font-bold">Promo Codes</h1>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader>
              <CardTitle>Redeem Code</CardTitle>
              <CardDescription>Enter a promotional code to receive rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter promo code"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="border-zinc-700 bg-zinc-800"
                />
                <Button
                  onClick={handleRedeemCode}
                  disabled={!promoCode.trim() || isSubmitting}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {isSubmitting ? <Casino className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                  Redeem
                </Button>
              </div>

              {message && (
                <div
                  className={`mt-4 rounded-lg p-3 ${
                    message.type === "success" ? "bg-green-900/50 text-green-300" : "bg-red-900/50 text-red-300"
                  }`}
                >
                  {message.text}
                </div>
              )}
            </CardContent>
            <CardFooter className="border-t border-zinc-800 px-6 py-4">
              <p className="text-sm text-zinc-400">
                Promo codes can provide bonuses like free credits or special tags for your account.
              </p>
            </CardFooter>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader>
              <CardTitle>Redeemed Codes</CardTitle>
              <CardDescription>History of codes you've already used</CardDescription>
            </CardHeader>
            <CardContent>
              {redeemedCodes.length > 0 ? (
                <div className="space-y-3">
                  {redeemedCodes.map((code, index) => (
                    <div key={index} className="rounded-lg border border-zinc-800 p-3">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="px-3 py-1">
                          {code.code}
                        </Badge>
                        <span className="text-xs text-zinc-400">{new Date(code.redeemedAt).toLocaleDateString()}</span>
                      </div>
                      <p className="mt-2 text-sm text-zinc-300">
                        <Gift className="mr-1 inline-block h-4 w-4 text-red-400" />
                        {code.reward}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="rounded-lg border border-zinc-800 p-6 text-center">
                  <Gift className="mx-auto mb-2 h-8 w-8 text-zinc-500" />
                  <p className="text-zinc-400">You haven't redeemed any promo codes yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 border-zinc-800 bg-zinc-900">
          <CardHeader>
            <CardTitle>Where to Find Promo Codes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-semibold">Social Media</h3>
                <p className="text-sm text-zinc-400">
                  Follow our social media accounts for exclusive promo codes and giveaways.
                </p>
              </div>
              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-semibold">Email Newsletter</h3>
                <p className="text-sm text-zinc-400">
                  Subscribe to our newsletter to receive promo codes directly in your inbox.
                </p>
              </div>
              <div className="rounded-lg border border-zinc-800 p-4">
                <h3 className="mb-2 font-semibold">Special Events</h3>
                <p className="text-sm text-zinc-400">
                  Participate in tournaments and special events to earn exclusive promo codes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AccountLayout>
  )
}
