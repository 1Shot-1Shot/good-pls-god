import Link from "next/link"
import { CastleIcon as Casino, ChevronRight, CreditCard } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { GameCard } from "@/components/game-card"
import { UserBalance } from "@/components/user-balance"
import { ChatBubble } from "@/components/chat/chat-bubble"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-2">
            <Casino className="h-6 w-6 text-red-500" />
            <span className="text-xl font-bold">LuckyStrike Casino</span>
          </div>
          <div className="flex items-center gap-4">
            <UserBalance />
            <Button size="sm" variant="outline" className="border-zinc-700 bg-zinc-800 text-white hover:bg-zinc-700">
              <CreditCard className="mr-2 h-4 w-4" />
              Deposit
            </Button>
            <Link href="/auth/login">
              <Button size="sm" className="bg-red-600 hover:bg-red-700">
                Login
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1 px-4 py-8">
        <div className="mx-auto max-w-7xl">
          <section className="mb-12">
            <div className="rounded-xl bg-gradient-to-r from-red-600 to-purple-600 p-8 text-center">
              <h1 className="mb-2 text-4xl font-bold">Welcome to LuckyStrike Casino</h1>
              <p className="mb-6 text-lg">Try your luck with our exciting games and win big!</p>
              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button size="lg" className="bg-white text-black hover:bg-zinc-200">
                  Play Now
                </Button>
                <Link href="/auth/register">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white bg-transparent text-white hover:bg-white/10"
                  >
                    Create Account
                  </Button>
                </Link>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold">Featured Games</h2>
              <Link href="/games" className="flex items-center text-sm text-zinc-400 hover:text-white">
                View All
                <ChevronRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <GameCard
                title="Slots Bonanza"
                description="Spin to win with 5 reels and multiple paylines"
                image="/placeholder.svg?height=200&width=400"
                icon="🎰"
                href="/games/slots"
              />
              <GameCard
                title="Roulette Royale"
                description="Place your bets on red, black, or your lucky number"
                image="/placeholder.svg?height=200&width=400"
                icon="🎡"
                href="/games/roulette"
              />
              <GameCard
                title="Blackjack"
                description="Beat the dealer to 21 without going bust"
                image="/placeholder.svg?height=200&width=400"
                icon="🃏"
                href="/games/blackjack"
              />
              <GameCard
                title="Dice Roll"
                description="Bet on dice combinations and win big"
                image="/placeholder.svg?height=200&width=400"
                icon="🎲"
                href="/games/dice"
              />
            </div>
          </section>

          <section className="mb-12">
            <h2 className="mb-6 text-2xl font-bold">More Games</h2>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <GameCard
                title="Crash"
                description="Cash out before the multiplier crashes"
                image="/placeholder.svg?height=200&width=400"
                icon="📉"
                href="/games/crash"
              />
              <GameCard
                title="Coin Flip"
                description="Heads or tails? Double your money"
                image="/placeholder.svg?height=200&width=400"
                icon="🪙"
                href="/games/coin-flip"
              />
              <GameCard
                title="Mines"
                description="Uncover tiles without hitting a mine"
                image="/placeholder.svg?height=200&width=400"
                icon="💣"
                href="/games/mines"
              />
              <GameCard
                title="Number Wheel"
                description="Spin the wheel and win prizes"
                image="/placeholder.svg?height=200&width=400"
                icon="🔢"
                href="/games/number-wheel"
              />
            </div>
          </section>

          <section className="mb-12">
            <h2 className="mb-6 text-2xl font-bold">Recent Winners</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="border-zinc-800 bg-zinc-900">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">Player{i + 1}</p>
                          <span className="rounded bg-red-500/20 px-1.5 py-0.5 text-xs font-medium text-red-300">
                            {i === 0 ? "Admin" : i === 1 ? "Owner" : "User"}
                          </span>
                        </div>
                        <p className="text-sm text-zinc-400">Won ${(Math.random() * 10000).toFixed(2)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            <div className="col-span-2 rounded-xl border border-zinc-800 bg-zinc-900 p-6">
              <h2 className="mb-4 text-xl font-bold">Live Tournament</h2>
              <div className="mb-4 rounded-lg bg-zinc-800 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <h3 className="font-medium">Texas Hold'em Championship</h3>
                  <span className="rounded-full bg-green-500/20 px-2 py-1 text-xs font-medium text-green-300">
                    Live Now
                  </span>
                </div>
                <p className="mb-2 text-sm text-zinc-400">Prize Pool: $25,000</p>
                <div className="flex flex-wrap gap-2">
                  <div className="rounded-full bg-zinc-700 px-3 py-1 text-xs">24 Players</div>
                  <div className="rounded-full bg-zinc-700 px-3 py-1 text-xs">Final Table</div>
                </div>
              </div>
              <Button className="w-full bg-red-600 hover:bg-red-700">Join Tournament</Button>
            </div>

            <div className="rounded-xl border border-zinc-800 bg-zinc-900 p-6">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-bold">Live Chat</h2>
                <span className="rounded-full bg-green-500 px-2 py-1 text-xs font-medium">12 Online</span>
              </div>
              <div className="mb-4 h-64 space-y-4 overflow-y-auto rounded-lg bg-zinc-800 p-4">
                <ChatBubble username="JackAce" message="Just won 5000 on slots!" time="2 min ago" userType="User" />
                <ChatBubble
                  username="CasinoAdmin"
                  message="Welcome to our new Blackjack tables everyone!"
                  time="5 min ago"
                  userType="Admin"
                />
                <ChatBubble
                  username="PokerQueen"
                  message="Anyone up for a poker tournament?"
                  time="10 min ago"
                  userType="User"
                />
                <ChatBubble
                  username="LuckyOwner"
                  message="We've added 50% bonus on all deposits today!"
                  time="15 min ago"
                  userType="Owner"
                />
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Type a message..."
                  className="flex-1 rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-2 text-white"
                  disabled
                />
                <Button disabled className="bg-red-600 hover:bg-red-700">
                  Send
                </Button>
              </div>
              <p className="mt-2 text-center text-xs text-zinc-500">Login to join the conversation</p>
            </div>
          </section>
        </div>
      </main>
      <footer className="border-t border-zinc-800 bg-zinc-950 px-4 py-6">
        <div className="mx-auto max-w-7xl">
          <div className="mb-4 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <h3 className="mb-3 text-lg font-bold">Games</h3>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li>
                  <Link href="/games/slots" className="hover:text-white">
                    Slots
                  </Link>
                </li>
                <li>
                  <Link href="/games/roulette" className="hover:text-white">
                    Roulette
                  </Link>
                </li>
                <li>
                  <Link href="/games/blackjack" className="hover:text-white">
                    Blackjack
                  </Link>
                </li>
                <li>
                  <Link href="/games/dice" className="hover:text-white">
                    Dice
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-3 text-lg font-bold">Account</h3>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li>
                  <Link href="/auth/register" className="hover:text-white">
                    Register
                  </Link>
                </li>
                <li>
                  <Link href="/auth/login" className="hover:text-white">
                    Login
                  </Link>
                </li>
                <li>
                  <Link href="/account" className="hover:text-white">
                    My Account
                  </Link>
                </li>
                <li>
                  <Link href="/account/transactions" className="hover:text-white">
                    Transaction History
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-3 text-lg font-bold">Support</h3>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li>
                  <Link href="/support" className="hover:text-white">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/support/faq" className="hover:text-white">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/support/contact" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/support/responsible-gaming" className="hover:text-white">
                    Responsible Gaming
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-3 text-lg font-bold">About</h3>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/about/terms" className="hover:text-white">
                    Terms & Conditions
                  </Link>
                </li>
                <li>
                  <Link href="/about/privacy" className="hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/about/careers" className="hover:text-white">
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-zinc-800 pt-4 text-center text-sm text-zinc-500">
            <p>© 2025 LuckyStrike Casino. All rights reserved. Please gamble responsibly.</p>
            <p className="mt-1">This is a demo application. No real money is involved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
