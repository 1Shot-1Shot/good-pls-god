"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, Download, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminLayout } from "@/components/admin/admin-layout"

interface ActivityLog {
  id: string
  action: string
  user: string
  timestamp: string
  details: string
  ip?: string
  userAgent?: string
  category: "user" | "admin" | "game" | "financial" | "security"
}

export default function LogsPage() {
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [logs, setLogs] = useState<ActivityLog[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [actionFilter, setActionFilter] = useState("all")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [isLoading, setIsLoading] = useState(true)
  const [dateRange, setDateRange] = useState("all")

  useEffect(() => {
    // Check if user is admin or manager
    const userRole = localStorage.getItem("userRole")
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"

    if (!isLoggedIn || (userRole !== "admin" && userRole !== "manager")) {
      router.push("/auth/login")
      return
    }

    setIsAdmin(userRole === "admin")

    // Get logs from localStorage or use sample logs
    const storedLogs = localStorage.getItem("activityLogs")
    let allLogs: ActivityLog[] = []

    if (storedLogs) {
      const parsedLogs = JSON.parse(storedLogs)

      // Convert simple logs to the enhanced format if needed
      allLogs = parsedLogs.map((log: any, index: number) => {
        if (!log.id) {
          return {
            id: `log-${index}`,
            action: log.action,
            user: log.user,
            timestamp: log.timestamp,
            details: log.details,
            category: getCategoryFromAction(log.action),
          }
        }
        return log
      })
    }

    // Add sample logs if we don't have many
    if (allLogs.length < 10) {
      const sampleLogs: ActivityLog[] = [
        {
          id: "log-1",
          action: "User Login",
          user: "JackAce",
          timestamp: "2025-05-18T10:30:00Z",
          details: "User logged in from Chrome/Windows",
          ip: "192.168.1.1",
          userAgent: "Chrome/Windows",
          category: "user",
        },
        {
          id: "log-2",
          action: "Game Started",
          user: "PokerQueen",
          timestamp: "2025-05-18T09:45:00Z",
          details: "Started Blackjack game with $100 bet",
          ip: "192.168.1.2",
          category: "game",
        },
        {
          id: "log-3",
          action: "User Registration",
          user: "NewPlayer123",
          timestamp: "2025-05-18T08:15:00Z",
          details: "New user registered with email newplayer@example.com",
          ip: "192.168.1.3",
          category: "user",
        },
        {
          id: "log-4",
          action: "Deposit",
          user: "SlotMaster",
          timestamp: "2025-05-17T22:10:00Z",
          details: "Deposited $500 via credit card",
          ip: "192.168.1.4",
          category: "financial",
        },
        {
          id: "log-5",
          action: "Withdrawal Request",
          user: "RouletteKing",
          timestamp: "2025-05-17T20:30:00Z",
          details: "Requested withdrawal of $1,200 to bank account",
          ip: "192.168.1.5",
          category: "financial",
        },
        {
          id: "log-6",
          action: "Game Won",
          user: "JackAce",
          timestamp: "2025-05-17T18:45:00Z",
          details: "Won $750 on Slots Bonanza",
          ip: "192.168.1.1",
          category: "game",
        },
        {
          id: "log-7",
          action: "User Suspended",
          user: "CasinoAdmin",
          timestamp: "2025-05-17T15:20:00Z",
          details: "Suspended user GamblerX for suspicious activity",
          ip: "192.168.1.6",
          category: "admin",
        },
        {
          id: "log-8",
          action: "Settings Changed",
          user: "LuckyManager",
          timestamp: "2025-05-17T14:10:00Z",
          details: "Updated site maintenance schedule",
          ip: "192.168.1.7",
          category: "admin",
        },
        {
          id: "log-9",
          action: "Failed Login Attempt",
          user: "Unknown",
          timestamp: "2025-05-17T12:05:00Z",
          details: "Failed login attempt for account JackAce",
          ip: "192.168.1.8",
          category: "security",
        },
        {
          id: "log-10",
          action: "Password Reset",
          user: "PokerQueen",
          timestamp: "2025-05-17T10:30:00Z",
          details: "Password reset requested and completed",
          ip: "192.168.1.2",
          category: "security",
        },
        {
          id: "log-11",
          action: "Promo Code Created",
          user: "CasinoAdmin",
          timestamp: "2025-05-16T16:45:00Z",
          details: "Created promo code SUMMER100 with $100 bonus",
          ip: "192.168.1.6",
          category: "admin",
        },
        {
          id: "log-12",
          action: "Promo Code Redeemed",
          user: "NewPlayer123",
          timestamp: "2025-05-16T14:20:00Z",
          details: "Redeemed promo code WELCOME50 for $50 bonus",
          ip: "192.168.1.3",
          category: "financial",
        },
      ]

      allLogs = [...allLogs, ...sampleLogs]
      localStorage.setItem("activityLogs", JSON.stringify(allLogs))
    }

    setLogs(allLogs)
    setIsLoading(false)
  }, [router])

  const getCategoryFromAction = (action: string): "user" | "admin" | "game" | "financial" | "security" => {
    action = action.toLowerCase()

    if (action.includes("login") || action.includes("registration") || action.includes("user")) {
      return "user"
    } else if (action.includes("admin") || action.includes("settings") || action.includes("role")) {
      return "admin"
    } else if (
      action.includes("game") ||
      action.includes("play") ||
      action.includes("won") ||
      action.includes("loss")
    ) {
      return "game"
    } else if (
      action.includes("deposit") ||
      action.includes("withdrawal") ||
      action.includes("balance") ||
      action.includes("transaction")
    ) {
      return "financial"
    } else {
      return "security"
    }
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  const handleActionFilter = (value: string) => {
    setActionFilter(value)
  }

  const handleCategoryFilter = (value: string) => {
    setCategoryFilter(value)
  }

  const handleDateRangeChange = (value: string) => {
    setDateRange(value)
  }

  const getFilteredLogs = () => {
    return logs
      .filter((log) => {
        // Apply search filter
        const matchesSearch =
          log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
          log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
          log.action.toLowerCase().includes(searchQuery.toLowerCase())

        // Apply action filter
        const matchesAction = actionFilter === "all" || log.action.includes(actionFilter)

        // Apply category filter
        const matchesCategory = categoryFilter === "all" || log.category === categoryFilter

        // Apply date range filter
        let matchesDateRange = true
        const logDate = new Date(log.timestamp)
        const now = new Date()

        if (dateRange === "today") {
          const today = new Date()
          today.setHours(0, 0, 0, 0)
          matchesDateRange = logDate >= today
        } else if (dateRange === "yesterday") {
          const yesterday = new Date()
          yesterday.setDate(yesterday.getDate() - 1)
          yesterday.setHours(0, 0, 0, 0)

          const today = new Date()
          today.setHours(0, 0, 0, 0)

          matchesDateRange = logDate >= yesterday && logDate < today
        } else if (dateRange === "week") {
          const weekAgo = new Date()
          weekAgo.setDate(weekAgo.getDate() - 7)
          matchesDateRange = logDate >= weekAgo
        } else if (dateRange === "month") {
          const monthAgo = new Date()
          monthAgo.setMonth(monthAgo.getMonth() - 1)
          matchesDateRange = logDate >= monthAgo
        }

        return matchesSearch && matchesAction && matchesCategory && matchesDateRange
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
  }

  // Get unique action types for filter
  const actionTypes = ["all", ...new Set(logs.map((log) => log.action))]

  const exportLogs = () => {
    const filteredLogs = getFilteredLogs()
    const csv = [
      ["ID", "Timestamp", "User", "Action", "Category", "IP", "Details"].join(","),
      ...filteredLogs.map((log) =>
        [
          log.id,
          new Date(log.timestamp).toISOString(),
          log.user,
          log.action,
          log.category,
          log.ip || "N/A",
          `"${log.details.replace(/"/g, '""')}"`,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `activity_logs_${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  const filteredLogs = getFilteredLogs()

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <h1 className="text-2xl font-bold">Activity Logs</h1>
          <div className="flex flex-wrap gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-zinc-400" />
              <Input
                type="search"
                placeholder="Search logs..."
                className="w-full border-zinc-700 bg-zinc-800 pl-9 text-white sm:w-64"
                value={searchQuery}
                onChange={handleSearch}
              />
            </div>
            <Button
              variant="outline"
              className="border-zinc-700 bg-zinc-800 text-white hover:bg-zinc-700"
              onClick={exportLogs}
            >
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <TabsList className="grid w-full grid-cols-5 sm:w-auto">
              <TabsTrigger value="all" onClick={() => setCategoryFilter("all")}>
                All
              </TabsTrigger>
              <TabsTrigger value="user" onClick={() => setCategoryFilter("user")}>
                User
              </TabsTrigger>
              <TabsTrigger value="game" onClick={() => setCategoryFilter("game")}>
                Game
              </TabsTrigger>
              <TabsTrigger value="financial" onClick={() => setCategoryFilter("financial")}>
                Financial
              </TabsTrigger>
              <TabsTrigger value="security" onClick={() => setCategoryFilter("security")}>
                Security
              </TabsTrigger>
            </TabsList>

            <div className="flex gap-2">
              <Select value={actionFilter} onValueChange={handleActionFilter}>
                <SelectTrigger className="w-full border-zinc-700 bg-zinc-800 text-white sm:w-40">
                  <SelectValue placeholder="Filter by action" />
                </SelectTrigger>
                <SelectContent className="border-zinc-700 bg-zinc-800 text-white">
                  {actionTypes.map((action) => (
                    <SelectItem key={action} value={action} className="hover:bg-zinc-700">
                      {action === "all" ? "All Actions" : action}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={dateRange} onValueChange={handleDateRangeChange}>
                <SelectTrigger className="w-full border-zinc-700 bg-zinc-800 text-white sm:w-40">
                  <SelectValue placeholder="Date range" />
                </SelectTrigger>
                <SelectContent className="border-zinc-700 bg-zinc-800 text-white">
                  <SelectItem value="all" className="hover:bg-zinc-700">
                    All Time
                  </SelectItem>
                  <SelectItem value="today" className="hover:bg-zinc-700">
                    Today
                  </SelectItem>
                  <SelectItem value="yesterday" className="hover:bg-zinc-700">
                    Yesterday
                  </SelectItem>
                  <SelectItem value="week" className="hover:bg-zinc-700">
                    Last 7 Days
                  </SelectItem>
                  <SelectItem value="month" className="hover:bg-zinc-700">
                    Last 30 Days
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <TabsContent value="all">
            <LogTable logs={filteredLogs} />
          </TabsContent>

          <TabsContent value="user">
            <LogTable logs={filteredLogs.filter((log) => log.category === "user")} />
          </TabsContent>

          <TabsContent value="game">
            <LogTable logs={filteredLogs.filter((log) => log.category === "game")} />
          </TabsContent>

          <TabsContent value="financial">
            <LogTable logs={filteredLogs.filter((log) => log.category === "financial")} />
          </TabsContent>

          <TabsContent value="security">
            <LogTable logs={filteredLogs.filter((log) => log.category === "security")} />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}

interface LogTableProps {
  logs: ActivityLog[]
}

function LogTable({ logs }: LogTableProps) {
  return (
    <Card className="border-zinc-800 bg-zinc-900">
      <CardHeader>
        <CardTitle>Activity Logs</CardTitle>
        <CardDescription>
          {logs.length} {logs.length === 1 ? "record" : "records"} found
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border border-zinc-800">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                  <TableHead className="text-zinc-400">Timestamp</TableHead>
                  <TableHead className="text-zinc-400">User</TableHead>
                  <TableHead className="text-zinc-400">Action</TableHead>
                  <TableHead className="text-zinc-400">Category</TableHead>
                  <TableHead className="text-zinc-400">IP Address</TableHead>
                  <TableHead className="text-zinc-400">Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.length > 0 ? (
                  logs.map((log, index) => (
                    <TableRow key={log.id || index} className="border-zinc-800 hover:bg-zinc-800/50">
                      <TableCell className="text-sm">{new Date(log.timestamp).toLocaleString()}</TableCell>
                      <TableCell className="font-medium">{log.user}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            log.category === "user"
                              ? "default"
                              : log.category === "admin"
                                ? "destructive"
                                : log.category === "game"
                                  ? "success"
                                  : log.category === "financial"
                                    ? "yellow"
                                    : "purple"
                          }
                        >
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{log.category.charAt(0).toUpperCase() + log.category.slice(1)}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">{log.ip || "N/A"}</TableCell>
                      <TableCell className="max-w-md truncate text-sm">{log.details}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No logs found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
