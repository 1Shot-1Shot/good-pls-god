"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { BarChart3, CastleIcon as Casino, DollarSign, Users } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AdminLayout } from "@/components/admin/admin-layout"

interface ActivityLog {
  action: string
  user: string
  timestamp: string
  details: string
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [recentLogs, setRecentLogs] = useState<ActivityLog[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is admin
    const userRole = localStorage.getItem("userRole")
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"

    if (!isLoggedIn || userRole !== "admin") {
      router.push("/auth/login")
      return
    }

    setIsAdmin(true)

    // Get recent logs
    const logs = JSON.parse(localStorage.getItem("activityLogs") || "[]")
    setRecentLogs(logs.slice(0, 5))

    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <h1 className="mb-6 text-2xl font-bold">Admin Dashboard</h1>

        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="mr-2 h-4 w-4 text-blue-400" />
                <span className="text-2xl font-bold">1,248</span>
              </div>
              <p className="mt-2 text-xs text-zinc-400">
                <span className="text-green-400">+12%</span> from last month
              </p>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <DollarSign className="mr-2 h-4 w-4 text-green-400" />
                <span className="text-2xl font-bold">$24,389</span>
              </div>
              <p className="mt-2 text-xs text-zinc-400">
                <span className="text-green-400">+18%</span> from last month
              </p>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Active Games</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Casino className="mr-2 h-4 w-4 text-red-400" />
                <span className="text-2xl font-bold">42</span>
              </div>
              <p className="mt-2 text-xs text-zinc-400">
                <span className="text-green-400">+5%</span> from last week
              </p>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Conversion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BarChart3 className="mr-2 h-4 w-4 text-purple-400" />
                <span className="text-2xl font-bold">8.2%</span>
              </div>
              <p className="mt-2 text-xs text-zinc-400">
                <span className="text-red-400">-2%</span> from last week
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentLogs.length > 0 ? (
                  recentLogs.map((log, index) => (
                    <div key={index} className="rounded-lg border border-zinc-800 p-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{log.action}</span>
                        <span className="text-xs text-zinc-400">{new Date(log.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="mt-1 text-sm text-zinc-400">User: {log.user}</p>
                      <p className="text-sm text-zinc-400">{log.details}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-zinc-400">No recent activity</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader>
              <CardTitle>Popular Games</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: "Slots Bonanza", plays: 3245, revenue: "$12,980" },
                  { name: "Blackjack", plays: 2187, revenue: "$8,748" },
                  { name: "Roulette Royale", plays: 1854, revenue: "$7,416" },
                  { name: "Texas Hold'em", plays: 1632, revenue: "$6,528" },
                ].map((game, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg border border-zinc-800 p-3">
                    <div>
                      <p className="font-medium">{game.name}</p>
                      <p className="text-sm text-zinc-400">{game.plays.toLocaleString()} plays</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-400">{game.revenue}</p>
                      <p className="text-xs text-zinc-400">revenue</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}
