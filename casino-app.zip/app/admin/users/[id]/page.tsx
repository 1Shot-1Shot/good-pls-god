"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ArrowLeft, Ban, CastleIcon as Casino, Coins, Shield, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AdminLayout } from "@/components/admin/admin-layout"
import { logActivity } from "@/lib/auth"

interface UserDetails {
  id: string
  username: string
  email: string
  role: "admin" | "manager" | "vip" | "user"
  balance: number
  status: "active" | "suspended" | "banned"
  lastLogin: string
  registeredDate: string
  tags: string[]
}

interface Transaction {
  id: string
  type: "deposit" | "withdrawal" | "bonus" | "game-win" | "game-loss" | "admin-adjustment"
  amount: number
  timestamp: string
  details: string
  adminId?: string
}

export default function UserDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const userId = params.id as string

  const [user, setUser] = useState<UserDetails | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [adjustmentAmount, setAdjustmentAmount] = useState("")
  const [adjustmentReason, setAdjustmentReason] = useState("")
  const [banReason, setBanReason] = useState("")
  const [newTag, setNewTag] = useState("")
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    // Check if user is admin or manager
    const userRole = localStorage.getItem("userRole")
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"

    if (!isLoggedIn || (userRole !== "admin" && userRole !== "manager")) {
      router.push("/auth/login")
      return
    }

    setIsAdmin(userRole === "admin")

    // Fetch user data
    fetchUserData()
  }, [router, userId])

  const fetchUserData = () => {
    // In a real app, this would be an API call
    // For demo, we'll use mock data from localStorage or create it

    // Get all users from localStorage or use mock data
    const storedUsers = localStorage.getItem("casinoUsers")
    let users = []

    if (storedUsers) {
      users = JSON.parse(storedUsers)
    } else {
      // Mock data
      users = [
        {
          id: "1",
          username: "CasinoAdmin",
          email: "admin@example.com",
          role: "admin",
          balance: 10000,
          status: "active",
          lastLogin: "2025-05-18T10:30:00Z",
          registeredDate: "2024-01-15T08:00:00Z",
          tags: ["Staff", "Developer"],
        },
        {
          id: "2",
          username: "LuckyManager",
          email: "manager@example.com",
          role: "manager",
          balance: 8000,
          status: "active",
          lastLogin: "2025-05-17T14:45:00Z",
          registeredDate: "2024-01-20T09:15:00Z",
          tags: ["Staff"],
        },
        {
          id: "3",
          username: "JackAce",
          email: "jack@example.com",
          role: "vip",
          balance: 2500,
          status: "active",
          lastLogin: "2025-05-18T09:15:00Z",
          registeredDate: "2024-02-10T14:30:00Z",
          tags: ["VIP", "High Roller"],
        },
        {
          id: "4",
          username: "PokerQueen",
          email: "queen@example.com",
          role: "user",
          balance: 7800,
          status: "active",
          lastLogin: "2025-05-18T08:20:00Z",
          registeredDate: "2024-03-05T11:45:00Z",
          tags: [],
        },
        {
          id: "5",
          username: "SlotMaster",
          email: "slots@example.com",
          role: "user",
          balance: 1200,
          status: "suspended",
          lastLogin: "2025-05-16T11:10:00Z",
          registeredDate: "2024-02-28T16:20:00Z",
          tags: ["Tournament Winner"],
        },
      ]
      localStorage.setItem("casinoUsers", JSON.stringify(users))
    }

    // Find the user by ID
    const foundUser = users.find((u: UserDetails) => u.id === userId)

    if (foundUser) {
      setUser(foundUser)
    } else {
      router.push("/admin/users")
    }

    // Get transactions from localStorage or create mock data
    const storedTransactions = localStorage.getItem(`transactions_${userId}`)
    let userTransactions = []

    if (storedTransactions) {
      userTransactions = JSON.parse(storedTransactions)
    } else {
      // Mock transactions
      userTransactions = [
        {
          id: "t1",
          type: "deposit",
          amount: 1000,
          timestamp: "2025-05-15T09:30:00Z",
          details: "Credit card deposit",
        },
        {
          id: "t2",
          type: "game-win",
          amount: 500,
          timestamp: "2025-05-16T14:20:00Z",
          details: "Blackjack win",
        },
        {
          id: "t3",
          type: "game-loss",
          amount: -200,
          timestamp: "2025-05-16T15:45:00Z",
          details: "Slots loss",
        },
        {
          id: "t4",
          type: "bonus",
          amount: 100,
          timestamp: "2025-05-17T10:00:00Z",
          details: "Welcome bonus",
        },
      ]
      localStorage.setItem(`transactions_${userId}`, JSON.stringify(userTransactions))
    }

    setTransactions(userTransactions)
    setIsLoading(false)
  }

  const handleBalanceAdjustment = () => {
    if (!adjustmentAmount || !adjustmentReason) return

    const amount = Number.parseFloat(adjustmentAmount)
    if (isNaN(amount)) return

    // Update user balance
    if (user) {
      const newBalance = user.balance + amount

      // Update user in state
      setUser({
        ...user,
        balance: newBalance,
      })

      // Add transaction record
      const newTransaction: Transaction = {
        id: `t${Date.now()}`,
        type: "admin-adjustment",
        amount: amount,
        timestamp: new Date().toISOString(),
        details: adjustmentReason,
        adminId: localStorage.getItem("userName") || "Admin",
      }

      const updatedTransactions = [newTransaction, ...transactions]
      setTransactions(updatedTransactions)

      // Update localStorage
      updateUserInStorage(user.id, { balance: newBalance })
      localStorage.setItem(`transactions_${userId}`, JSON.stringify(updatedTransactions))

      // Log the activity
      logActivity(
        "Balance Adjustment",
        `Adjusted ${user.username}'s balance by ${amount > 0 ? "+" : ""}${amount}. Reason: ${adjustmentReason}`,
      )

      // Reset form
      setAdjustmentAmount("")
      setAdjustmentReason("")
    }
  }

  const handleStatusChange = (status: "active" | "suspended" | "banned") => {
    if (!user) return

    // Update user status
    setUser({
      ...user,
      status: status,
    })

    // Update localStorage
    updateUserInStorage(user.id, { status })

    // Log the activity
    logActivity(
      `User ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      `Changed ${user.username}'s status to ${status}${status === "banned" && banReason ? `. Reason: ${banReason}` : ""}`,
    )

    setBanReason("")
  }

  const handleRoleChange = (role: string) => {
    if (!user || !isAdmin) return

    // Update user role
    setUser({
      ...user,
      role: role as any,
    })

    // Update localStorage
    updateUserInStorage(user.id, { role })

    // Log the activity
    logActivity("Role Change", `Changed ${user.username}'s role to ${role}`)
  }

  const handleAddTag = () => {
    if (!user || !newTag) return

    if (!user.tags.includes(newTag)) {
      const updatedTags = [...user.tags, newTag]

      // Update user tags
      setUser({
        ...user,
        tags: updatedTags,
      })

      // Update localStorage
      updateUserInStorage(user.id, { tags: updatedTags })

      // Log the activity
      logActivity("Tag Added", `Added tag "${newTag}" to ${user.username}`)

      setNewTag("")
    }
  }

  const handleRemoveTag = (tag: string) => {
    if (!user) return

    const updatedTags = user.tags.filter((t) => t !== tag)

    // Update user tags
    setUser({
      ...user,
      tags: updatedTags,
    })

    // Update localStorage
    updateUserInStorage(user.id, { tags: updatedTags })

    // Log the activity
    logActivity("Tag Removed", `Removed tag "${tag}" from ${user.username}`)
  }

  const updateUserInStorage = (userId: string, updates: Partial<UserDetails>) => {
    const storedUsers = localStorage.getItem("casinoUsers")

    if (storedUsers) {
      const users = JSON.parse(storedUsers)
      const updatedUsers = users.map((u: UserDetails) => {
        if (u.id === userId) {
          return { ...u, ...updates }
        }
        return u
      })

      localStorage.setItem("casinoUsers", JSON.stringify(updatedUsers))
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  if (!user) {
    return (
      <AdminLayout>
        <div className="p-6">
          <div className="text-center">
            <h1 className="text-2xl font-bold">User not found</h1>
            <Button className="mt-4" onClick={() => router.push("/admin/users")}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Users
            </Button>
          </div>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={() => router.push("/admin/users")}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            <h1 className="text-2xl font-bold">{user.username}</h1>
            <Badge
              variant={user.status === "active" ? "success" : user.status === "suspended" ? "warning" : "destructive"}
            >
              {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
            </Badge>
            <Badge
              variant={
                user.role === "admin"
                  ? "destructive"
                  : user.role === "manager"
                    ? "purple"
                    : user.role === "vip"
                      ? "yellow"
                      : "default"
              }
            >
              {user.role.toUpperCase()}
            </Badge>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-4 py-2">
            <Coins className="h-4 w-4 text-yellow-500" />
            <span className="font-medium">{user.balance.toLocaleString()}</span>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="mb-4 grid w-full grid-cols-4 lg:w-auto">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="actions">Actions</TabsTrigger>
            <TabsTrigger value="logs">Logs</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>User Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-zinc-400">Username</p>
                      <p className="font-medium">{user.username}</p>
                    </div>
                    <div>
                      <p className="text-sm text-zinc-400">Email</p>
                      <p className="font-medium">{user.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-zinc-400">Registered</p>
                      <p className="font-medium">{new Date(user.registeredDate).toLocaleDateString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-zinc-400">Last Login</p>
                      <p className="font-medium">{new Date(user.lastLogin).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tags & Badges</CardTitle>
                  <CardDescription>Special tags assigned to this user</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 flex flex-wrap gap-2">
                    {user.tags.length > 0 ? (
                      user.tags.map((tag, index) => (
                        <Badge key={index} className="flex items-center gap-1 px-3 py-1">
                          {tag}
                          <button
                            onClick={() => handleRemoveTag(tag)}
                            className="ml-1 rounded-full bg-zinc-700 p-1 text-xs hover:bg-zinc-600"
                          >
                            ×
                          </button>
                        </Badge>
                      ))
                    ) : (
                      <p className="text-sm text-zinc-400">No tags assigned</p>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      placeholder="New tag"
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      className="border-zinc-700 bg-zinc-800"
                    />
                    <Button onClick={handleAddTag} disabled={!newTag}>
                      Add
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Account Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-4">
                      <p className="text-sm text-zinc-400">Total Deposits</p>
                      <p className="text-2xl font-bold">
                        $
                        {transactions
                          .filter((t) => t.type === "deposit")
                          .reduce((sum, t) => sum + t.amount, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-4">
                      <p className="text-sm text-zinc-400">Total Winnings</p>
                      <p className="text-2xl font-bold text-green-500">
                        $
                        {transactions
                          .filter((t) => t.type === "game-win")
                          .reduce((sum, t) => sum + t.amount, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-4">
                      <p className="text-sm text-zinc-400">Total Losses</p>
                      <p className="text-2xl font-bold text-red-500">
                        $
                        {Math.abs(
                          transactions.filter((t) => t.type === "game-loss").reduce((sum, t) => sum + t.amount, 0),
                        ).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="transactions">
            <Card>
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>All financial transactions for this user</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-zinc-800">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-zinc-800 bg-zinc-900">
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Type</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Amount</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Details</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Admin</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.length > 0 ? (
                          transactions.map((transaction, index) => (
                            <tr key={index} className="border-b border-zinc-800 hover:bg-zinc-800/50">
                              <td className="px-4 py-3 text-sm">{new Date(transaction.timestamp).toLocaleString()}</td>
                              <td className="px-4 py-3">
                                <Badge
                                  variant={
                                    transaction.type === "deposit" ||
                                    transaction.type === "game-win" ||
                                    transaction.type === "bonus"
                                      ? "success"
                                      : transaction.type === "game-loss" || transaction.type === "withdrawal"
                                        ? "destructive"
                                        : "outline"
                                  }
                                >
                                  {transaction.type.replace("-", " ").toUpperCase()}
                                </Badge>
                              </td>
                              <td
                                className={`px-4 py-3 font-medium ${
                                  transaction.amount >= 0 ? "text-green-500" : "text-red-500"
                                }`}
                              >
                                {transaction.amount >= 0 ? "+" : ""}
                                {transaction.amount.toLocaleString()}
                              </td>
                              <td className="px-4 py-3 text-sm">{transaction.details}</td>
                              <td className="px-4 py-3 text-sm">{transaction.adminId ? transaction.adminId : "-"}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="px-4 py-3 text-center text-sm text-zinc-400">
                              No transactions found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="actions">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Balance Adjustment</CardTitle>
                  <CardDescription>Add or remove funds from user's account</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount (use negative for deduction)</Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="100"
                        value={adjustmentAmount}
                        onChange={(e) => setAdjustmentAmount(e.target.value)}
                        className="border-zinc-700 bg-zinc-800"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reason">Reason</Label>
                      <Textarea
                        id="reason"
                        placeholder="Reason for adjustment"
                        value={adjustmentReason}
                        onChange={(e) => setAdjustmentReason(e.target.value)}
                        className="border-zinc-700 bg-zinc-800"
                      />
                    </div>
                    <Button
                      onClick={handleBalanceAdjustment}
                      disabled={!adjustmentAmount || !adjustmentReason}
                      className="w-full"
                    >
                      <Coins className="mr-2 h-4 w-4" />
                      Apply Adjustment
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Account Status</CardTitle>
                  <CardDescription>Change user account status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between rounded-lg border border-zinc-800 p-3">
                      <div className="flex items-center gap-2">
                        <User className="h-5 w-5 text-green-500" />
                        <div>
                          <p className="font-medium">Active</p>
                          <p className="text-sm text-zinc-400">User has full access</p>
                        </div>
                      </div>
                      <Button
                        variant={user.status === "active" ? "default" : "outline"}
                        onClick={() => handleStatusChange("active")}
                        disabled={user.status === "active"}
                      >
                        {user.status === "active" ? "Current" : "Activate"}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-zinc-800 p-3">
                      <div className="flex items-center gap-2">
                        <Shield className="h-5 w-5 text-yellow-500" />
                        <div>
                          <p className="font-medium">Suspended</p>
                          <p className="text-sm text-zinc-400">Temporary restriction</p>
                        </div>
                      </div>
                      <Button
                        variant={user.status === "suspended" ? "default" : "outline"}
                        onClick={() => handleStatusChange("suspended")}
                        disabled={user.status === "suspended"}
                      >
                        {user.status === "suspended" ? "Current" : "Suspend"}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border border-zinc-800 p-3">
                      <div className="flex items-center gap-2">
                        <Ban className="h-5 w-5 text-red-500" />
                        <div>
                          <p className="font-medium">Banned</p>
                          <p className="text-sm text-zinc-400">Permanent restriction</p>
                        </div>
                      </div>
                      <Button
                        variant={user.status === "banned" ? "default" : "destructive"}
                        onClick={() => handleStatusChange("banned")}
                        disabled={user.status === "banned"}
                      >
                        {user.status === "banned" ? "Current" : "Ban"}
                      </Button>
                    </div>

                    {user.status !== "banned" && (
                      <div className="space-y-2">
                        <Label htmlFor="banReason">Ban Reason</Label>
                        <Textarea
                          id="banReason"
                          placeholder="Reason for banning (required for ban action)"
                          value={banReason}
                          onChange={(e) => setBanReason(e.target.value)}
                          className="border-zinc-700 bg-zinc-800"
                        />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {isAdmin && (
                <Card>
                  <CardHeader>
                    <CardTitle>Role Management</CardTitle>
                    <CardDescription>Change user role (Admin only)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Select defaultValue={user.role} onValueChange={handleRoleChange}>
                        <SelectTrigger className="border-zinc-700 bg-zinc-800">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent className="border-zinc-700 bg-zinc-800">
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="vip">VIP</SelectItem>
                          <SelectItem value="manager">Manager</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>

                      <div className="rounded-lg border border-zinc-800 p-4">
                        <h4 className="mb-2 font-medium">Role Permissions</h4>
                        <div className="space-y-2 text-sm text-zinc-400">
                          <p>
                            • <span className="font-medium text-white">User:</span> Basic access to games and features
                          </p>
                          <p>
                            • <span className="font-medium text-white">VIP:</span> Premium features, higher limits,
                            special promotions
                          </p>
                          <p>
                            • <span className="font-medium text-white">Manager:</span> User management, transaction
                            handling, support tools
                          </p>
                          <p>
                            • <span className="font-medium text-white">Admin:</span> Full system access, role
                            management, configuration
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Additional account controls</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="email-notifications">Email Notifications</Label>
                        <p className="text-sm text-zinc-400">Receive promotional emails</p>
                      </div>
                      <Switch id="email-notifications" defaultChecked={true} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="login-alerts">Login Alerts</Label>
                        <p className="text-sm text-zinc-400">Notify on suspicious logins</p>
                      </div>
                      <Switch id="login-alerts" defaultChecked={true} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="deposit-limits">Deposit Limits</Label>
                        <p className="text-sm text-zinc-400">Enforce responsible gaming limits</p>
                      </div>
                      <Switch id="deposit-limits" defaultChecked={false} />
                    </div>

                    <Button variant="outline" className="w-full">
                      Reset Password
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle>Activity Logs</CardTitle>
                <CardDescription>User activity and admin actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-zinc-800">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-zinc-800 bg-zinc-900">
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Date</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Action</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">IP Address</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-zinc-400">Details</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          {
                            date: "2025-05-18T10:30:00Z",
                            action: "Login",
                            ip: "192.168.1.1",
                            details: "Successful login from Chrome/Windows",
                          },
                          {
                            date: "2025-05-17T15:45:00Z",
                            action: "Game Play",
                            ip: "192.168.1.1",
                            details: "Played Blackjack for 45 minutes",
                          },
                          {
                            date: "2025-05-17T14:20:00Z",
                            action: "Deposit",
                            ip: "192.168.1.1",
                            details: "Added $500 via credit card",
                          },
                          {
                            date: "2025-05-16T09:15:00Z",
                            action: "Password Change",
                            ip: "192.168.1.1",
                            details: "Changed account password",
                          },
                          {
                            date: "2025-05-15T18:30:00Z",
                            action: "Promo Code",
                            ip: "192.168.1.1",
                            details: "Redeemed code WELCOME100",
                          },
                        ].map((log, index) => (
                          <tr key={index} className="border-b border-zinc-800 hover:bg-zinc-800/50">
                            <td className="px-4 py-3 text-sm">{new Date(log.date).toLocaleString()}</td>
                            <td className="px-4 py-3">
                              <Badge variant="outline">{log.action}</Badge>
                            </td>
                            <td className="px-4 py-3 text-sm">{log.ip}</td>
                            <td className="px-4 py-3 text-sm">{log.details}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}
