"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, MoreHorizontal, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { AdminLayout } from "@/components/admin/admin-layout"

interface User {
  id: string
  username: string
  email: string
  role: "admin" | "owner" | "user"
  balance: number
  status: "active" | "suspended" | "banned"
  lastLogin: string
}

const MOCK_USERS: User[] = [
  {
    id: "1",
    username: "CasinoAdmin",
    email: "admin@example.com",
    role: "admin",
    balance: 10000,
    status: "active",
    lastLogin: "2025-05-18T10:30:00Z",
  },
  {
    id: "2",
    username: "LuckyOwner",
    email: "owner@example.com",
    role: "owner",
    balance: 50000,
    status: "active",
    lastLogin: "2025-05-17T14:45:00Z",
  },
  {
    id: "3",
    username: "JackAce",
    email: "jack@example.com",
    role: "user",
    balance: 2500,
    status: "active",
    lastLogin: "2025-05-18T09:15:00Z",
  },
  {
    id: "4",
    username: "PokerQueen",
    email: "queen@example.com",
    role: "user",
    balance: 7800,
    status: "active",
    lastLogin: "2025-05-18T08:20:00Z",
  },
  {
    id: "5",
    username: "SlotMaster",
    email: "slots@example.com",
    role: "user",
    balance: 1200,
    status: "suspended",
    lastLogin: "2025-05-16T11:10:00Z",
  },
  {
    id: "6",
    username: "BlackjackPro",
    email: "blackjack@example.com",
    role: "user",
    balance: 4500,
    status: "active",
    lastLogin: "2025-05-17T22:30:00Z",
  },
  {
    id: "7",
    username: "RouletteKing",
    email: "roulette@example.com",
    role: "user",
    balance: 3200,
    status: "active",
    lastLogin: "2025-05-18T01:45:00Z",
  },
  {
    id: "8",
    username: "GamblerX",
    email: "gambler@example.com",
    role: "user",
    balance: 100,
    status: "banned",
    lastLogin: "2025-05-10T16:20:00Z",
  },
]

export default function UsersPage() {
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [users, setUsers] = useState<User[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is admin
    const userRole = localStorage.getItem("userRole")
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"

    if (!isLoggedIn || userRole !== "admin") {
      router.push("/auth/login")
      return
    }

    setIsAdmin(true)
    setUsers(MOCK_USERS)
    setIsLoading(false)
  }, [router])

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAction = (action: string, userId: string) => {
    // Log the action
    const logs = JSON.parse(localStorage.getItem("activityLogs") || "[]")
    const user = users.find((u) => u.id === userId)

    logs.push({
      action: `User ${action}`,
      user: "CasinoAdmin",
      timestamp: new Date().toISOString(),
      details: `${action} user ${user?.username} (${user?.email})`,
    })

    localStorage.setItem("activityLogs", JSON.stringify(logs))

    // Update user status in the UI
    if (action === "Suspend" || action === "Ban" || action === "Activate") {
      const newStatus = action === "Suspend" ? "suspended" : action === "Ban" ? "banned" : "active"

      setUsers(users.map((user) => (user.id === userId ? { ...user, status: newStatus as any } : user)))
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <h1 className="text-2xl font-bold">User Management</h1>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-zinc-400" />
              <Input
                type="search"
                placeholder="Search users..."
                className="w-full border-zinc-700 bg-zinc-800 pl-9 text-white sm:w-64"
                value={searchQuery}
                onChange={handleSearch}
              />
            </div>
            <Button className="bg-red-600 hover:bg-red-700">Add User</Button>
          </div>
        </div>

        <div className="rounded-lg border border-zinc-800 bg-zinc-900">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                  <TableHead className="text-zinc-400">Username</TableHead>
                  <TableHead className="text-zinc-400">Email</TableHead>
                  <TableHead className="text-zinc-400">Role</TableHead>
                  <TableHead className="text-zinc-400">Balance</TableHead>
                  <TableHead className="text-zinc-400">Status</TableHead>
                  <TableHead className="text-zinc-400">Last Login</TableHead>
                  <TableHead className="text-right text-zinc-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id} className="border-zinc-800 hover:bg-zinc-800/50">
                    <TableCell className="font-medium">{user.username}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <span
                        className={`rounded-full px-2 py-1 text-xs font-medium ${
                          user.role === "admin"
                            ? "bg-red-500/20 text-red-300"
                            : user.role === "owner"
                              ? "bg-purple-500/20 text-purple-300"
                              : "bg-blue-500/20 text-blue-300"
                        }`}
                      >
                        {user.role}
                      </span>
                    </TableCell>
                    <TableCell>${user.balance.toLocaleString()}</TableCell>
                    <TableCell>
                      <span
                        className={`rounded-full px-2 py-1 text-xs font-medium ${
                          user.status === "active"
                            ? "bg-green-500/20 text-green-300"
                            : user.status === "suspended"
                              ? "bg-yellow-500/20 text-yellow-300"
                              : "bg-red-500/20 text-red-300"
                        }`}
                      >
                        {user.status}
                      </span>
                    </TableCell>
                    <TableCell>{new Date(user.lastLogin).toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0 text-zinc-400 hover:bg-zinc-800">
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="border-zinc-800 bg-zinc-900 text-white">
                          <DropdownMenuItem
                            className="cursor-pointer hover:bg-zinc-800"
                            onClick={() => handleAction("Edit", user.id)}
                          >
                            Edit
                          </DropdownMenuItem>
                          {user.status === "active" ? (
                            <DropdownMenuItem
                              className="cursor-pointer hover:bg-zinc-800"
                              onClick={() => handleAction("Suspend", user.id)}
                            >
                              Suspend
                            </DropdownMenuItem>
                          ) : user.status === "suspended" ? (
                            <DropdownMenuItem
                              className="cursor-pointer hover:bg-zinc-800"
                              onClick={() => handleAction("Activate", user.id)}
                            >
                              Activate
                            </DropdownMenuItem>
                          ) : null}
                          {user.status !== "banned" ? (
                            <DropdownMenuItem
                              className="cursor-pointer text-red-400 hover:bg-zinc-800 hover:text-red-300"
                              onClick={() => handleAction("Ban", user.id)}
                            >
                              Ban
                            </DropdownMenuItem>
                          ) : (
                            <DropdownMenuItem
                              className="cursor-pointer hover:bg-zinc-800"
                              onClick={() => handleAction("Activate", user.id)}
                            >
                              Unban
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </AdminLayout>
  )
}
