"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CastleIcon as Casino, Gift, Plus, Tag, Trash2, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { AdminLayout } from "@/components/admin/admin-layout"
import { logActivity } from "@/lib/auth"

interface PromoCode {
  id: string
  code: string
  type: "money" | "tag" | "both"
  amount?: number
  tag?: string
  usageLimit: number
  usageCount: number
  expiryDate: string
  isActive: boolean
  createdBy: string
  createdAt: string
}

export default function PromoCodesPage() {
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newCode, setNewCode] = useState({
    code: "",
    type: "money",
    amount: 100,
    tag: "",
    usageLimit: 100,
    expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0], // 30 days from now
    isActive: true,
  })

  useEffect(() => {
    // Check if user is admin or manager
    const userRole = localStorage.getItem("userRole")
    const isLoggedIn = localStorage.getItem("userLoggedIn") === "true"

    if (!isLoggedIn || (userRole !== "admin" && userRole !== "manager")) {
      router.push("/auth/login")
      return
    }

    setIsAdmin(userRole === "admin")

    // Load promo codes from localStorage or create mock data
    const storedCodes = localStorage.getItem("promoCodes")

    if (storedCodes) {
      setPromoCodes(JSON.parse(storedCodes))
    } else {
      // Mock data
      const mockCodes: PromoCode[] = [
        {
          id: "1",
          code: "WELCOME100",
          type: "money",
          amount: 100,
          usageLimit: 1000,
          usageCount: 458,
          expiryDate: "2025-12-31",
          isActive: true,
          createdBy: "CasinoAdmin",
          createdAt: "2025-01-15T10:30:00Z",
        },
        {
          id: "2",
          code: "VIP2025",
          type: "tag",
          tag: "VIP",
          usageLimit: 50,
          usageCount: 12,
          expiryDate: "2025-06-30",
          isActive: true,
          createdBy: "LuckyManager",
          createdAt: "2025-02-10T14:45:00Z",
        },
        {
          id: "3",
          code: "SUMMER500",
          type: "both",
          amount: 500,
          tag: "Summer Promotion",
          usageLimit: 200,
          usageCount: 0,
          expiryDate: "2025-08-31",
          isActive: false,
          createdBy: "CasinoAdmin",
          createdAt: "2025-05-01T09:15:00Z",
        },
      ]

      setPromoCodes(mockCodes)
      localStorage.setItem("promoCodes", JSON.stringify(mockCodes))
    }

    setIsLoading(false)
  }, [router])

  const handleCreateCode = () => {
    // Validate form
    if (
      !newCode.code ||
      (newCode.type === "money" && !newCode.amount) ||
      (newCode.type === "tag" && !newCode.tag) ||
      (newCode.type === "both" && (!newCode.amount || !newCode.tag))
    ) {
      return
    }

    // Create new promo code
    const createdCode: PromoCode = {
      id: Date.now().toString(),
      code: newCode.code.toUpperCase(),
      type: newCode.type as "money" | "tag" | "both",
      amount: newCode.type === "tag" ? undefined : newCode.amount,
      tag: newCode.type === "money" ? undefined : newCode.tag,
      usageLimit: newCode.usageLimit,
      usageCount: 0,
      expiryDate: newCode.expiryDate,
      isActive: newCode.isActive,
      createdBy: localStorage.getItem("userName") || "Admin",
      createdAt: new Date().toISOString(),
    }

    // Add to state and localStorage
    const updatedCodes = [createdCode, ...promoCodes]
    setPromoCodes(updatedCodes)
    localStorage.setItem("promoCodes", JSON.stringify(updatedCodes))

    // Log activity
    logActivity(
      "Promo Code Created",
      `Created promo code ${createdCode.code} with ${
        createdCode.type === "money"
          ? `$${createdCode.amount} bonus`
          : createdCode.type === "tag"
            ? `"${createdCode.tag}" tag`
            : `$${createdCode.amount} bonus and "${createdCode.tag}" tag`
      }`,
    )

    // Reset form and close dialog
    setNewCode({
      code: "",
      type: "money",
      amount: 100,
      tag: "",
      usageLimit: 100,
      expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      isActive: true,
    })
    setIsDialogOpen(false)
  }

  const toggleCodeStatus = (id: string) => {
    const updatedCodes = promoCodes.map((code) => {
      if (code.id === id) {
        const newStatus = !code.isActive

        // Log activity
        logActivity("Promo Code Status Changed", `${newStatus ? "Activated" : "Deactivated"} promo code ${code.code}`)

        return { ...code, isActive: newStatus }
      }
      return code
    })

    setPromoCodes(updatedCodes)
    localStorage.setItem("promoCodes", JSON.stringify(updatedCodes))
  }

  const deleteCode = (id: string) => {
    const codeToDelete = promoCodes.find((code) => code.id === id)

    if (codeToDelete) {
      // Log activity
      logActivity("Promo Code Deleted", `Deleted promo code ${codeToDelete.code}`)

      const updatedCodes = promoCodes.filter((code) => code.id !== id)
      setPromoCodes(updatedCodes)
      localStorage.setItem("promoCodes", JSON.stringify(updatedCodes))
    }
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <h1 className="text-2xl font-bold">Promo Codes</h1>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-red-600 hover:bg-red-700">
                <Plus className="mr-2 h-4 w-4" />
                Create Promo Code
              </Button>
            </DialogTrigger>
            <DialogContent className="border-zinc-800 bg-zinc-900 text-white sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Create New Promo Code</DialogTitle>
                <DialogDescription>Create a new promotional code for users to redeem.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="code" className="text-right">
                    Code
                  </Label>
                  <Input
                    id="code"
                    placeholder="SUMMER100"
                    className="col-span-3 border-zinc-700 bg-zinc-800"
                    value={newCode.code}
                    onChange={(e) => setNewCode({ ...newCode, code: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="type" className="text-right">
                    Type
                  </Label>
                  <Select value={newCode.type} onValueChange={(value) => setNewCode({ ...newCode, type: value })}>
                    <SelectTrigger id="type" className="col-span-3 border-zinc-700 bg-zinc-800">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent className="border-zinc-700 bg-zinc-800">
                      <SelectItem value="money">Money Bonus</SelectItem>
                      <SelectItem value="tag">Tag/Badge</SelectItem>
                      <SelectItem value="both">Both</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {(newCode.type === "money" || newCode.type === "both") && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="amount" className="text-right">
                      Amount
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="100"
                      className="col-span-3 border-zinc-700 bg-zinc-800"
                      value={newCode.amount}
                      onChange={(e) => setNewCode({ ...newCode, amount: Number.parseInt(e.target.value) })}
                    />
                  </div>
                )}

                {(newCode.type === "tag" || newCode.type === "both") && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="tag" className="text-right">
                      Tag
                    </Label>
                    <Input
                      id="tag"
                      placeholder="VIP"
                      className="col-span-3 border-zinc-700 bg-zinc-800"
                      value={newCode.tag}
                      onChange={(e) => setNewCode({ ...newCode, tag: e.target.value })}
                    />
                  </div>
                )}

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="usageLimit" className="text-right">
                    Usage Limit
                  </Label>
                  <Input
                    id="usageLimit"
                    type="number"
                    placeholder="100"
                    className="col-span-3 border-zinc-700 bg-zinc-800"
                    value={newCode.usageLimit}
                    onChange={(e) => setNewCode({ ...newCode, usageLimit: Number.parseInt(e.target.value) })}
                  />
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="expiryDate" className="text-right">
                    Expiry Date
                  </Label>
                  <Input
                    id="expiryDate"
                    type="date"
                    className="col-span-3 border-zinc-700 bg-zinc-800"
                    value={newCode.expiryDate}
                    onChange={(e) => setNewCode({ ...newCode, expiryDate: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="isActive" className="text-right">
                    Active
                  </Label>
                  <div className="col-span-3 flex items-center">
                    <Switch
                      id="isActive"
                      checked={newCode.isActive}
                      onCheckedChange={(checked) => setNewCode({ ...newCode, isActive: checked })}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateCode}>Create</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Total Codes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Gift className="mr-2 h-4 w-4 text-purple-400" />
                <span className="text-2xl font-bold">{promoCodes.length}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Active Codes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Tag className="mr-2 h-4 w-4 text-green-400" />
                <span className="text-2xl font-bold">{promoCodes.filter((code) => code.isActive).length}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-zinc-800 bg-zinc-900">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-zinc-400">Total Redemptions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="mr-2 h-4 w-4 text-blue-400" />
                <span className="text-2xl font-bold">{promoCodes.reduce((sum, code) => sum + code.usageCount, 0)}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 border-zinc-800 bg-zinc-900">
          <CardHeader>
            <CardTitle>All Promo Codes</CardTitle>
            <CardDescription>Manage promotional codes for your users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-zinc-800">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-zinc-800 hover:bg-zinc-800/50">
                      <TableHead className="text-zinc-400">Code</TableHead>
                      <TableHead className="text-zinc-400">Type</TableHead>
                      <TableHead className="text-zinc-400">Reward</TableHead>
                      <TableHead className="text-zinc-400">Usage</TableHead>
                      <TableHead className="text-zinc-400">Expiry</TableHead>
                      <TableHead className="text-zinc-400">Status</TableHead>
                      <TableHead className="text-zinc-400">Created By</TableHead>
                      <TableHead className="text-right text-zinc-400">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {promoCodes.map((code) => (
                      <TableRow key={code.id} className="border-zinc-800 hover:bg-zinc-800/50">
                        <TableCell className="font-medium">{code.code}</TableCell>
                        <TableCell>
                          <Badge
                            variant={code.type === "money" ? "success" : code.type === "tag" ? "outline" : "purple"}
                          >
                            {code.type === "money" ? "Money" : code.type === "tag" ? "Tag" : "Both"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {code.type === "money" ? (
                            <span className="text-green-500">${code.amount}</span>
                          ) : code.type === "tag" ? (
                            <Badge variant="outline">{code.tag}</Badge>
                          ) : (
                            <div className="flex flex-col gap-1">
                              <span className="text-green-500">${code.amount}</span>
                              <Badge variant="outline" className="w-fit">
                                {code.tag}
                              </Badge>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-2 w-full rounded-full bg-zinc-700">
                              <div
                                className="h-2 rounded-full bg-blue-500"
                                style={{ width: `${Math.min(100, (code.usageCount / code.usageLimit) * 100)}%` }}
                              ></div>
                            </div>
                            <span className="whitespace-nowrap text-xs">
                              {code.usageCount}/{code.usageLimit}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {new Date(code.expiryDate) < new Date() ? (
                            <span className="text-red-400">Expired</span>
                          ) : (
                            new Date(code.expiryDate).toLocaleDateString()
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant={code.isActive ? "success" : "destructive"}>
                            {code.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </TableCell>
                        <TableCell>{code.createdBy}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => toggleCodeStatus(code.id)}
                              className="h-8 border-zinc-700 hover:bg-zinc-800"
                            >
                              {code.isActive ? "Deactivate" : "Activate"}
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => deleteCode(code.id)} className="h-8">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-zinc-800 px-6 py-4">
            <p className="text-sm text-zinc-400">
              Promo codes can be redeemed by users in their account section. Inactive or expired codes cannot be
              redeemed.
            </p>
          </CardFooter>
        </Card>
      </div>
    </AdminLayout>
  )
}
