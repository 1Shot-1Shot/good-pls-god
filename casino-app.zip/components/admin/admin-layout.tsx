"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  BarChart3,
  CastleIcon as Casino,
  ClipboardList,
  CreditCard,
  LogOut,
  Menu,
  MessageSquare,
  Settings,
  Users,
  X,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent } from "@/components/ui/sheet"

interface AdminLayoutProps {
  children: React.ReactNode
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [username, setUsername] = useState("")

  useEffect(() => {
    const storedUsername = localStorage.getItem("userName")
    if (storedUsername) {
      setUsername(storedUsername)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("userLoggedIn")
    localStorage.removeItem("userRole")
    router.push("/auth/login")
  }

  const navigation = [
    { name: "Dashboard", href: "/admin", icon: BarChart3 },
    { name: "Users", href: "/admin/users", icon: Users },
    { name: "Activity Logs", href: "/admin/logs", icon: ClipboardList },
    { name: "Transactions", href: "/admin/transactions", icon: CreditCard },
    { name: "Chat Moderation", href: "/admin/chat", icon: MessageSquare },
    { name: "Settings", href: "/admin/settings", icon: Settings },
  ]

  return (
    <div className="flex min-h-screen bg-black text-white">
      {/* Desktop sidebar */}
      <div className="hidden border-r border-zinc-800 bg-zinc-950 md:fixed md:inset-y-0 md:flex md:w-64 md:flex-col">
        <div className="flex flex-1 flex-col overflow-y-auto">
          <div className="flex h-16 flex-shrink-0 items-center border-b border-zinc-800 px-4">
            <Casino className="h-8 w-8 text-red-500" />
            <span className="ml-2 text-xl font-bold">Admin Panel</span>
          </div>
          <div className="mt-5 flex flex-1 flex-col">
            <nav className="flex-1 space-y-1 px-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`group flex items-center rounded-md px-2 py-2 text-sm font-medium ${
                      isActive ? "bg-red-600 text-white" : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                    }`}
                  >
                    <item.icon
                      className={`mr-3 h-5 w-5 flex-shrink-0 ${
                        isActive ? "text-white" : "text-zinc-400 group-hover:text-white"
                      }`}
                    />
                    {item.name}
                  </Link>
                )
              })}
            </nav>
          </div>
          <div className="flex flex-shrink-0 border-t border-zinc-800 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{username}</p>
                <p className="text-xs text-zinc-400">Admin</p>
              </div>
            </div>
            <Button
              variant="ghost"
              className="ml-auto text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="flex md:hidden">
        <Button
          variant="ghost"
          className="m-2 p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <span className="sr-only">Open sidebar</span>
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side="left" className="border-zinc-800 bg-zinc-950 p-0">
          <div className="flex h-16 items-center border-b border-zinc-800 px-6">
            <Casino className="h-8 w-8 text-red-500" />
            <span className="ml-2 text-xl font-bold">Admin Panel</span>
            <Button
              variant="ghost"
              className="ml-auto p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <nav className="mt-5 space-y-1 px-4">
            {navigation.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`group flex items-center rounded-md px-2 py-2 text-sm font-medium ${
                    isActive ? "bg-red-600 text-white" : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <item.icon
                    className={`mr-3 h-5 w-5 flex-shrink-0 ${
                      isActive ? "text-white" : "text-zinc-400 group-hover:text-white"
                    }`}
                  />
                  {item.name}
                </Link>
              )
            })}
          </nav>
          <div className="absolute bottom-0 flex w-full flex-shrink-0 border-t border-zinc-800 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{username}</p>
                <p className="text-xs text-zinc-400">Admin</p>
              </div>
            </div>
            <Button
              variant="ghost"
              className="ml-auto text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="flex flex-1 flex-col md:pl-64">{children}</div>
    </div>
  )
}
