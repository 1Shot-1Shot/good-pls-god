"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface CardAnimationProps {
  children: React.ReactNode
  index: number
  isDealing?: boolean
  isFlipping?: boolean
  delay?: number
}

export function CardAnimation({
  children,
  index,
  isDealing = false,
  isFlipping = false,
  delay = 0,
}: CardAnimationProps) {
  const [isVisible, setIsVisible] = useState(!isDealing)

  useEffect(() => {
    if (isDealing) {
      const timer = setTimeout(() => {
        setIsVisible(true)
      }, delay)
      return () => clearTimeout(timer)
    }
  }, [isDealing, delay])

  if (!isVisible) return null

  return (
    <motion.div
      initial={isDealing ? { x: -300, y: -100, opacity: 0, rotateY: 180 } : false}
      animate={{
        x: 0,
        y: 0,
        opacity: 1,
        rotateY: isFlipping ? [180, 0] : 0,
        scale: [isDealing ? 0.8 : 1, 1],
      }}
      transition={{
        type: "spring",
        stiffness: 300,
        damping: 20,
        delay: isDealing ? index * 0.15 + delay : 0,
        duration: isFlipping ? 0.5 : 0.3,
      }}
      className="h-full w-full"
    >
      {children}
    </motion.div>
  )
}
