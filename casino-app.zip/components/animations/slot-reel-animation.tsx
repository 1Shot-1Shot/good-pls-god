"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface SlotReelAnimationProps {
  spinning: boolean
  symbol: string
  index: number
  isMiddleRow?: boolean
}

export function SlotReelAnimation({ spinning, symbol, index, isMiddleRow = false }: SlotReelAnimationProps) {
  const [symbols, setSymbols] = useState<string[]>([])

  useEffect(() => {
    if (spinning) {
      // Generate random symbols for animation
      const allSymbols = ["🍒", "🍋", "🍊", "🍇", "💎", "7️⃣", "🎰"]
      const randomSymbols = Array.from({ length: 20 }, () => allSymbols[Math.floor(Math.random() * allSymbols.length)])
      setSymbols(randomSymbols)
    }
  }, [spinning])

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
      {spinning ? (
        <motion.div
          initial={{ y: -1000 }}
          animate={{ y: 1000 }}
          transition={{
            duration: 1 + index * 0.2,
            ease: "easeInOut",
            times: [0, 1],
          }}
          className="absolute flex flex-col"
        >
          {symbols.map((s, i) => (
            <div key={i} className="flex h-20 w-full items-center justify-center text-4xl">
              {s}
            </div>
          ))}
        </motion.div>
      ) : (
        <motion.div
          initial={spinning ? { scale: 0.8, opacity: 0 } : false}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className={`text-4xl ${isMiddleRow && symbol !== "❓" ? "animate-pulse" : ""}`}
        >
          {symbol}
        </motion.div>
      )}
    </div>
  )
}
