"use client"

import type React from "react"

import { motion } from "framer-motion"

interface ChipAnimationProps {
  children: React.ReactNode
  isWinning?: boolean
  amount?: number
}

export function ChipAnimation({ children, isWinning = false, amount = 0 }: ChipAnimationProps) {
  return (
    <div className="relative">
      <motion.div
        animate={
          isWinning
            ? {
                y: [0, -20, 0],
                scale: [1, 1.1, 1],
              }
            : {}
        }
        transition={{
          duration: 0.5,
          repeat: isWinning ? 2 : 0,
          repeatType: "loop",
        }}
      >
        {children}
      </motion.div>

      {isWinning && amount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 0 }}
          animate={{ opacity: 1, y: -40 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute left-1/2 top-0 -translate-x-1/2 whitespace-nowrap rounded-full bg-green-500 px-2 py-1 text-xs font-bold text-white"
        >
          +{amount}
        </motion.div>
      )}
    </div>
  )
}
