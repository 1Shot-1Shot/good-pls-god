"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"

interface RouletteWheelAnimationProps {
  spinning: boolean
  result: number | null
  onSpinComplete?: () => void
}

export function RouletteWheelAnimation({ spinning, result, onSpinComplete }: RouletteWheelAnimationProps) {
  const wheelRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!spinning && result !== null && onSpinComplete) {
      const timer = setTimeout(() => {
        onSpinComplete()
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [spinning, result, onSpinComplete])

  // Calculate rotation based on result
  // Each number on a roulette wheel has a specific position
  const getRotationForNumber = (num: number | null) => {
    if (num === null) return 0

    // This is a simplified mapping - a real wheel would need precise angles
    // Standard wheel order: 0, 32, 15, 19, 4, 21, 2, 25, etc.
    const baseRotation = 360 * 5 // Spin 5 full rotations for effect
    const numberPosition = (num * 9.73) % 360 // Simplified position calculation

    return baseRotation + numberPosition
  }

  return (
    <div className="relative h-32 w-32">
      <motion.div
        ref={wheelRef}
        initial={false}
        animate={{
          rotate: spinning ? getRotationForNumber(result) : 0,
          scale: spinning ? 1.05 : 1,
        }}
        transition={{
          type: "spring",
          stiffness: spinning ? 10 : 300,
          damping: spinning ? 50 : 20,
          duration: spinning ? 3 : 0.5,
        }}
        className="absolute inset-0 rounded-full border-4 border-yellow-500 bg-green-800"
      >
        {/* Wheel segments would go here in a real implementation */}
        <div className="absolute inset-0 flex items-center justify-center">
          {spinning ? (
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            >
              <div className="h-12 w-12 rounded-full bg-red-600"></div>
            </motion.div>
          ) : (
            result !== null && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`flex h-24 w-24 items-center justify-center rounded-full text-3xl font-bold ${
                  result === 0
                    ? "bg-green-600"
                    : [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36].includes(result)
                      ? "bg-red-600"
                      : "bg-zinc-900"
                }`}
              >
                {result}
              </motion.div>
            )
          )}
        </div>
      </motion.div>

      {/* Ball indicator */}
      {spinning && (
        <motion.div
          className="absolute h-4 w-4 rounded-full bg-white"
          initial={{ x: 0, y: -50, opacity: 1 }}
          animate={{
            x: [0, 20, -20, 10, -10, 0],
            y: [-50, -40, -45, -48, -50],
            opacity: [1, 1, 1, 1, 0],
          }}
          transition={{
            duration: 3,
            times: [0, 0.2, 0.4, 0.6, 0.8, 1],
            repeat: 0,
          }}
        />
      )}
    </div>
  )
}
