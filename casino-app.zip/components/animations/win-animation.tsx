"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import confetti from "canvas-confetti"

interface WinAnimationProps {
  isWinning: boolean
  amount: number
  message?: string
}

export function WinAnimation({ isWinning, amount, message }: WinAnimationProps) {
  const [showConfetti, setShowConfetti] = useState(false)

  useEffect(() => {
    if (isWinning && amount > 0) {
      setShowConfetti(true)

      // Create confetti effect
      const duration = 2 * 1000
      const end = Date.now() + duration

      const colors = ["#ff0000", "#ffd700", "#ffffff"]

      const frame = () => {
        confetti({
          particleCount: 2,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors,
        })

        confetti({
          particleCount: 2,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors,
        })

        if (Date.now() < end) {
          requestAnimationFrame(frame)
        }
      }

      frame()

      // Clean up
      const timer = setTimeout(() => {
        setShowConfetti(false)
      }, duration)

      return () => clearTimeout(timer)
    }
  }, [isWinning, amount])

  if (!isWinning || amount <= 0) return null

  return (
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.8, opacity: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="fixed inset-0 z-50 flex items-center justify-center"
    >
      <div className="pointer-events-none relative rounded-xl bg-black/70 p-8 text-center backdrop-blur-sm">
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-2 text-2xl font-bold text-white"
        >
          {message || "You Win!"}
        </motion.div>

        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            delay: 0.4,
            type: "spring",
            stiffness: 300,
            damping: 20,
          }}
          className="text-4xl font-bold text-green-500"
        >
          +${amount}
        </motion.div>
      </div>
    </motion.div>
  )
}
