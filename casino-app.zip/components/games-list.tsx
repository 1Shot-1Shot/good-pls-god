import {
  Dices,
  PlaySquare,
  CircleDollarSign,
  TrendingDown,
  Bomb,
  Hash,
  SplitSquareVertical,
  Coins,
  Club,
  Diamond,
} from "lucide-react"

export function GamesList() {
  return (
    <div className="p-6 rounded-lg bg-zinc-900 border border-zinc-800">
      <h2 className="text-2xl font-bold mb-4">Casino Games List</h2>
      <ul className="space-y-2">
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <PlaySquare className="h-5 w-5 mr-3 text-red-500" />
          <span>Slots Bonanza - A classic slot machine game with multiple reels and paylines</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <CircleDollarSign className="h-5 w-5 mr-3 text-red-500" />
          <span>Roulette Royale - Bet on numbers, colors, or combinations on the roulette wheel</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <SplitSquareVertical className="h-5 w-5 mr-3 text-red-500" />
          <span>Blackjack - Card game where players aim to get a hand value of 21 without going over</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Dices className="h-5 w-5 mr-3 text-red-500" />
          <span>Dice Roll - Bet on dice combinations with customizable odds</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <TrendingDown className="h-5 w-5 mr-3 text-red-500" />
          <span>Crash - Watch the multiplier grow and cash out before it crashes</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Coins className="h-5 w-5 mr-3 text-red-500" />
          <span>Coin Flip - Simple heads or tails betting game with 2x payout</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Bomb className="h-5 w-5 mr-3 text-red-500" />
          <span>Mines - Uncover tiles without hitting hidden mines for increasing multipliers</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Hash className="h-5 w-5 mr-3 text-red-500" />
          <span>Number Wheel - Spin the wheel and win based on where it lands</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Club className="h-5 w-5 mr-3 text-red-500" />
          <span>Five Card Draw - Poker variant where players can replace cards in their hand</span>
        </li>
        <li className="p-3 bg-zinc-800 rounded-lg flex items-center">
          <Diamond className="h-5 w-5 mr-3 text-red-500" />
          <span>Texas Hold'em - Popular poker variant with community cards (tournament mode)</span>
        </li>
      </ul>
    </div>
  )
}
