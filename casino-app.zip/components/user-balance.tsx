"use client"

import { useEffect, useState } from "react"
import { Coins } from "lucide-react"

export function UserBalance() {
  const [balance, setBalance] = useState(5000)

  useEffect(() => {
    // In a real app, we would fetch this from an API
    const storedBalance = localStorage.getItem("userBalance")
    if (storedBalance) {
      setBalance(Number.parseInt(storedBalance))
    } else {
      localStorage.setItem("userBalance", balance.toString())
    }
  }, [balance])

  return (
    <div className="flex items-center gap-2 rounded-full bg-zinc-800 px-4 py-1">
      <Coins className="h-4 w-4 text-yellow-500" />
      <span className="font-medium">{balance.toLocaleString()}</span>
    </div>
  )
}
