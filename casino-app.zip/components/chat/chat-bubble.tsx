interface ChatBubbleProps {
  username: string
  message: string
  time: string
  userType: "Admin" | "Owner" | "User"
}

export function ChatBubble({ username, message, time, userType }: ChatBubbleProps) {
  const getBadgeColor = () => {
    switch (userType) {
      case "Admin":
        return "bg-red-500/20 text-red-300"
      case "Owner":
        return "bg-purple-500/20 text-purple-300"
      case "User":
        return "bg-blue-500/20 text-blue-300"
      default:
        return "bg-zinc-500/20 text-zinc-300"
    }
  }

  return (
    <div className="rounded-lg bg-zinc-900 p-3">
      <div className="mb-1 flex items-center gap-2">
        <span className="font-medium">{username}</span>
        <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${getBadgeColor()}`}>{userType}</span>
        <span className="ml-auto text-xs text-zinc-500">{time}</span>
      </div>
      <p className="text-sm text-zinc-300">{message}</p>
    </div>
  )
}
