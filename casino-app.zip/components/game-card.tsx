import Link from "next/link"
import type { ReactNode } from "react"

import { Card, CardContent } from "@/components/ui/card"

interface GameCardProps {
  title: string
  description: string
  image: string
  icon: ReactNode | string
  href: string
}

export function GameCard({ title, description, image, icon, href }: GameCardProps) {
  return (
    <Link href={href}>
      <Card className="overflow-hidden border-zinc-800 bg-zinc-900 transition-all hover:border-zinc-700 hover:bg-zinc-800">
        <div className="relative h-48 w-full">
          <div className="h-full w-full bg-cover bg-center" style={{ backgroundImage: `url(${image})` }} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
        </div>
        <CardContent className="p-4">
          <div className="mb-2 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-500 text-white">
              {typeof icon === "string" ? icon : icon}
            </div>
            <h3 className="text-lg font-bold">{title}</h3>
          </div>
          <p className="text-sm text-zinc-400">{description}</p>
        </CardContent>
      </Card>
    </Link>
  )
}
