"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { CastleIcon as Casino, CreditCard, Gift, History, LogOut, Menu, Settings, User, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import { UserBalance } from "@/components/user-balance"
import { getCurrentUser, logout } from "@/lib/auth"

interface AccountLayoutProps {
  children: React.ReactNode
}

export function AccountLayout({ children }: AccountLayoutProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const currentUser = getCurrentUser()

    if (!currentUser) {
      router.push("/auth/login?redirect=/account")
      return
    }

    setUser(currentUser)
    setIsLoading(false)
  }, [router])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const navigation = [
    { name: "Account Overview", href: "/account", icon: User },
    { name: "Transaction History", href: "/account/transactions", icon: History },
    { name: "Promo Codes", href: "/account/promo-code", icon: Gift },
    { name: "Payment Methods", href: "/account/payment", icon: CreditCard },
    { name: "Settings", href: "/account/settings", icon: Settings },
  ]

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black">
        <Casino className="h-8 w-8 animate-spin text-red-500" />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-black text-white">
      {/* Desktop sidebar */}
      <div className="hidden border-r border-zinc-800 bg-zinc-950 md:fixed md:inset-y-0 md:flex md:w-64 md:flex-col">
        <div className="flex flex-1 flex-col overflow-y-auto">
          <div className="flex h-16 flex-shrink-0 items-center border-b border-zinc-800 px-4">
            <Link href="/" className="flex items-center gap-2">
              <Casino className="h-8 w-8 text-red-500" />
              <span className="text-xl font-bold">LuckyStrike</span>
            </Link>
          </div>
          <div className="mt-5 flex flex-1 flex-col">
            <nav className="flex-1 space-y-1 px-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`group flex items-center rounded-md px-2 py-2 text-sm font-medium ${
                      isActive ? "bg-red-600 text-white" : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                    }`}
                  >
                    <item.icon
                      className={`mr-3 h-5 w-5 flex-shrink-0 ${
                        isActive ? "text-white" : "text-zinc-400 group-hover:text-white"
                      }`}
                    />
                    {item.name}
                  </Link>
                )
              })}
            </nav>
          </div>
          <div className="flex flex-shrink-0 border-t border-zinc-800 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{user?.username}</p>
                <p className="text-xs text-zinc-400">{user?.email}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              className="ml-auto text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="flex md:hidden">
        <Button
          variant="ghost"
          className="m-2 p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
          onClick={() => setIsMobileMenuOpen(true)}
        >
          <span className="sr-only">Open sidebar</span>
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side="left" className="border-zinc-800 bg-zinc-950 p-0">
          <div className="flex h-16 items-center border-b border-zinc-800 px-6">
            <Casino className="h-8 w-8 text-red-500" />
            <span className="ml-2 text-xl font-bold">Account</span>
            <Button
              variant="ghost"
              className="ml-auto p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          <nav className="mt-5 space-y-1 px-4">
            {navigation.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`group flex items-center rounded-md px-2 py-2 text-sm font-medium ${
                    isActive ? "bg-red-600 text-white" : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <item.icon
                    className={`mr-3 h-5 w-5 flex-shrink-0 ${
                      isActive ? "text-white" : "text-zinc-400 group-hover:text-white"
                    }`}
                  />
                  {item.name}
                </Link>
              )
            })}
          </nav>
          <div className="absolute bottom-0 flex w-full flex-shrink-0 border-t border-zinc-800 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-zinc-800"></div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{user?.username}</p>
                <p className="text-xs text-zinc-400">{user?.email}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              className="ml-auto text-zinc-400 hover:bg-zinc-800 hover:text-white"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <div className="flex flex-1 flex-col md:pl-64">
        <header className="border-b border-zinc-800 bg-zinc-950 px-4 py-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">My Account</h2>
            <UserBalance />
          </div>
        </header>
        {children}
      </div>
    </div>
  )
}
